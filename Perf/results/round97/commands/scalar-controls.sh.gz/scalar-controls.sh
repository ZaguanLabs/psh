set -eu
w=$PWD/.work/round97
python3 Perf/scalar-write-benchmark.py "$w/a/zsh" "$w/b/zsh" --boundaries --samples 7 --cpu 13 --output "$w/assign.json" > "$w/assign.log"
