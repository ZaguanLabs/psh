set -eu
w=$PWD/.work/round97
# Reuse round 94's viewport worker and sampling method across short and long inputs.
mkdir -p "$w/boundaries"
ln -sf "$PWD/Perf/results/round94/viewport.zsh" "$w/boundaries/viewport.zsh"
sed 's/\[(64, "ascii"), (10000, "ascii"), (10000, "wide")\]/[(n, "ascii") for n in (63, 64, 65, 255, 1024, 1086, 1087, 1088, 1089, 1090, 2048, 10000)] + [(10000, "wide")]/' Perf/results/round94/viewport.py > "$w/boundaries/viewport.py"
python3 "$w/boundaries/viewport.py" --shell "$w/b/zsh" --shell "$w/a/zsh" --project /home/stig/dev/ai/zaguan/labs/zcoder.zsh --cpu 13 --output "$w/boundaries.json"
