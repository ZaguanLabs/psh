set -eu
w=$PWD/.work/round96
mkdir -p "$w/a"
cp -p .work/round95/trial/runtime/bin/zsh "$w/a/zsh"
python3 Perf/check-pattern-module.py --baseline-build .work/rc0-release-baseline .work/rc0-release-baseline/Src/zsh .work/round95/b/zsh --output "$w/native-base.json" --memcheck
env -i PATH=/usr/bin:/bin LC_ALL=C.UTF-8 valgrind --tool=callgrind --callgrind-out-file="$w/viewport-base.cg" "$w/a/zsh" -df Perf/results/round94/viewport.zsh /home/stig/dev/ai/zaguan/labs/zcoder.zsh 10000 wide 64 > "$w/base.out" 2> "$w/base.log"
