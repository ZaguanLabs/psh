set -eu
w=$PWD/.work/round96
t=$w/trial
ref=$PWD/.work/rc0-release-baseline/Src/zsh
prev=$PWD/.work/round95/trial/runtime/bin/zsh
trial=$t/runtime/bin/zsh
labs=/home/stig/dev/ai/zaguan/labs
project=$labs/zcoder.zsh
# Use equally long invocation paths for the two development interpreters.
mkdir -p "$w/a" "$w/b"
cp -p "$prev" "$w/a/zsh"
cp -p "$trial" "$w/b/zsh"
a=$w/a/zsh
b=$w/b/zsh
timing=(python3 Perf/customer-benchmark.py --cpu 13 --labs "$labs" --challenge /home/stig/dev/challenge)
focus=(--case zcoder.zsh/coder-paste --case zcoder.zsh/coder-wide-layout --case zchat.zsh/chat-paste --case endgame/endgame-world)
python3 Perf/results/round94/viewport.py --shell "$a" --shell "$b" --shell "$ref" --project "$project" --cpu 13 --output "$w/viewport.json"
"${timing[@]}" "$a" "$b" --samples 9 --output "$w/first.json" > "$w/first.log"
"${timing[@]}" "$b" "$a" --samples 9 --output "$w/repeat.json" > "$w/repeat.log"
"${timing[@]}" "$ref" "$b" "${focus[@]}" --samples 5 --output "$w/pristine.json" > "$w/pristine.log"
bash "$w/boundaries.sh"
python3 Perf/memory-checkpoints.py --heap-mapping --shell "$a" --shell "$b" --labs "$labs" --challenge /home/stig/dev/challenge "${focus[@]}" --samples 5 --output "$w/memory.json" > "$w/memory.log"
python3 Perf/memory-checkpoints.py --heap-mapping --shell "$b" --shell "$a" --labs "$labs" --challenge /home/stig/dev/challenge --case zcoder.zsh/coder-wide-layout --samples 5 --cycles 120 --output "$w/long.json" > "$w/long.log"
for tag in a b; do
    build="$t/build"
    if [[ $tag == a ]]; then build=$PWD/.work/round95/trial/build; fi
    mkdir -p "$w/probe/$tag"
    cc -shared -fPIC -O2 -Wall -Werror -DMODULE -DHAVE_CONFIG_H -I"$build/Src" Perf/results/round94/literal.c -o "$w/probe/$tag/literal_probe.so"
done
python3 Perf/results/round94/viewport-memory.py --build "$a" "$w/probe/a" --build "$b" "$w/probe/b" --project "$project" --output "$w/viewport-memory.json"
env -i PATH=/usr/bin:/bin LC_ALL=C.UTF-8 valgrind --tool=callgrind --callgrind-out-file="$w/viewport-candidate.cg" "$b" -df Perf/results/round94/viewport.zsh "$project" 10000 wide 64 > "$w/trial.out" 2> "$w/trial.log"
cmp <(tail -n+2 "$w/base.out") <(tail -n+2 "$w/trial.out")
for tag in a b; do
    env -i PATH=/usr/bin:/bin LC_ALL=C.UTF-8 valgrind --tool=dhat --dhat-out-file="$w/viewport-$tag.dhat" "$w/$tag/zsh" -df Perf/results/round94/viewport.zsh "$project" 10000 wide 64 > "$w/$tag.out" 2> "$w/$tag.log"
    cmp <(tail -n+2 "$w/base.out") <(tail -n+2 "$w/$tag.out")
done
python3 Packaging/check-ohmyzsh.py --candidate "$trial" --output "$w/omz.json" > "$w/omz.log" 2>&1
python3 Perf/check-convfloat-loaders.py --candidate "$trial" --output "$w/loaders.json" > "$w/loaders.log"
make -C "$t/build" check > "$w/upstream.log" 2>&1
for loc in C C.UTF-8; do
    env -i LC_ALL="$loc" PATH=/usr/bin:/bin "$trial" -df Vendor/zjson/tests/run.zsh > "$w/zjson-$loc.log" 2>&1
done
python3 Perf/check-pattern-module.py --baseline-build "$PWD/.work/rc0-release-baseline" "$ref" "$trial" --output "$w/native.json" --memcheck > "$w/native.log"
python3 Perf/pattern-compare.py "$ref" "$trial" --extended --output "$w/pattern.json" > "$w/pattern.log"
python3 Perf/substitution-compare.py "$ref" "$trial" --output "$w/subst.json" > "$w/subst.log"
