set -eu
w=$PWD/.work/round96
# Reuse round 94's viewport worker and sampling method across short and long inputs.
mkdir -p "$w/boundaries"
ln -sf "$PWD/Perf/results/round94/viewport.zsh" "$w/boundaries/viewport.zsh"
sed 's/\[(64, "ascii"), (10000, "ascii"), (10000, "wide")\]/[(n, "ascii") for n in (64, 255, 508, 509, 510, 511, 512, 513, 514, 1024, 2048, 10000)] + [(10000, "wide")]/' Perf/results/round94/viewport.py > "$w/boundaries/viewport.py"
python3 "$w/boundaries/viewport.py" --shell "$w/b/zsh" --shell "$w/a/zsh" --project /home/stig/dev/ai/zaguan/labs/zcoder.zsh --cpu 13 --output "$w/boundaries.json"
