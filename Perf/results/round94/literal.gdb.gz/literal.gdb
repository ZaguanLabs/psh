set pagination off
set confirm off
break patadd if n > 4096
commands
silent
printf "append=%ld flags=%d compiler_flags=%d current=%ld capacity=%ld\n", n, paflags, patflags, patsize, patalloc
bt 3
continue
end
run
