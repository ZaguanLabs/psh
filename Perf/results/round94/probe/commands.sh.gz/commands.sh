set -eu
w=$PWD/.work/round94
for tag in "$@"; do
    case $tag in
        pristine) b=$PWD/.work/rc0-release-baseline; src=$PWD/.work/pristine; shell=$b/Src/zsh;;
        base) b=$PWD/.work/round92/shared/build; src=$b; shell=$PWD/.work/round92/shared/runtime/bin/zsh;;
        *) b=$w/$tag/build; src=$b; shell=$w/$tag/runtime/bin/zsh;;
    esac
    d=$w/probe/$tag
    mkdir -p "$d"
    cc -shared -fPIC -g -O2 -Wall -Werror -DMODULE -DHAVE_CONFIG_H -I"$b/Src" -I"$src/Src" Perf/results/round94/literal.c -o "$d/literal_probe.so"
    for mode in normal memcheck; do
        cmd=()
        if [[ $mode == memcheck ]]; then cmd=(valgrind --error-exitcode=97 --leak-check=no --log-file="$d/memcheck.log"); fi
        env -i PATH=/usr/bin:/bin LC_ALL=C.UTF-8 "${cmd[@]}" "$shell" -dfc 'module_path=("$1" $module_path); zmodload literal_probe && literal-probe' probe "$d" > "$d/$mode.out" 2> "$d/$mode.err"
        test ! -s "$d/$mode.err"
        test "$(tail -1 "$d/$mode.out")" = '120 literal checks and compiler transitions passed'
    done
done
