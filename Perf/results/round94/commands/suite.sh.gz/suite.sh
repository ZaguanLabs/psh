set -eu
w="$PWD/.work/round94"
d="$w/$1"
tag="$2"
shell="$d/runtime/bin/zsh"
cp -p "$shell" "$w/$tag/zsh"
bash "$w/run.sh" "$1" "$tag"
python3 Perf/results/round91/sourced.py --shell "$w/a/zsh" --shell "$w/$tag/zsh" --labs /home/stig/dev/ai/zaguan/labs --cpu 13 --output "$d/sourced.json"
paths=(--labs /home/stig/dev/ai/zaguan/labs --challenge /home/stig/dev/challenge)
focus=(--case zcoder.zsh/coder-paste --case zchat.zsh/chat-paste --case endgame/endgame-world --case zcoder.zsh/coder-wide-layout)
python3 Perf/memory-checkpoints.py --shell "$w/$tag/zsh" --shell "$w/a/zsh" "${paths[@]}" "${focus[@]}" --samples 5 --output "$d/memory-repeat.json" > "$d/memory-repeat.log"
bash "$w/checks.sh" "$1"
