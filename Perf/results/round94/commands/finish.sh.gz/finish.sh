set -eu
w=$PWD/.work/round94
project=/home/stig/dev/ai/zaguan/labs/zcoder.zsh
ref=$PWD/.work/rc0-release-baseline/Src/zsh
while [[ ! -f "$w/reuse/logs/ohmyzsh.log" ]]; do sleep 2; done
bash "$w/probe.sh" pristine base literal reuse
for trial in literal reuse; do
    d="$w/$trial"
    python3 Perf/pattern-compare.py "$ref" "$d/runtime/bin/zsh" --extended --output "$d/matching.json" > "$d/matching.log"
    python3 Perf/check-pattern-module.py --baseline-build "$PWD/.work/rc0-release-baseline" "$ref" "$d/runtime/bin/zsh" --memcheck --output "$d/bounded.json" > "$d/bounded.log"
    python3 Perf/substitution-compare.py "$ref" "$d/runtime/bin/zsh" --output "$d/substitution.json" > "$d/substitution.log"
done
for tag in a b c; do
    for bench in wide viewport; do
        d="$w/dhat/$tag/$bench"
        mkdir -p "$d"
        args=(Perf/customer-workload.zsh coder-wide-layout "$project" 1)
        if [[ $bench == viewport ]]; then args=(Perf/results/round94/viewport.zsh "$project" 10000 wide 64); fi
        env -i PATH=/usr/bin:/bin LC_ALL=C.UTF-8 valgrind --tool=dhat --dhat-out-file="$d/profile.json" "$w/$tag/zsh" -df "${args[@]}" > "$d/output" 2> "$d/log"
        cmp <(tail -n+2 "$w/dhat/a/$bench/output") <(tail -n+2 "$d/output")
    done
done
while ! rg -q '14237 checks, 0 failures' "$w/reuse/logs/zjson-C.UTF-8.log" 2>/dev/null; do sleep 2; done
python3 Perf/results/round94/viewport.py --shell "$w/a/zsh" --shell "$w/b/zsh" --shell "$w/c/zsh" --project "$project" --cpu 13 --output "$w/viewport.json"
python3 Perf/results/round94/viewport-memory.py --build "$w/a/zsh" "$w/probe/base" --build "$w/b/zsh" "$w/probe/literal" --build "$w/c/zsh" "$w/probe/reuse" --project "$project" --output "$w/viewport-memory.json"
python3 Perf/memory-checkpoints.py --shell "$w/a/zsh" --shell "$w/b/zsh" --shell "$w/c/zsh" --case zcoder.zsh/coder-wide-layout --samples 5 --cycles 120 --labs "${project%/*}" --challenge /home/stig/dev/challenge --output "$w/long-wide.json" > "$w/long-wide.log"
