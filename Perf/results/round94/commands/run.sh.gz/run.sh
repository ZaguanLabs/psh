set -eu
w=$PWD/.work/round94
d=$w/$1
tag=$2
a=$w/a/zsh
b=$w/$tag/zsh
labs=/home/stig/dev/ai/zaguan/labs
paths=(--labs "$labs" --challenge /home/stig/dev/challenge)
bench=(python3 Perf/customer-benchmark.py --cpu 13 "${paths[@]}")
focus=(--case zcoder.zsh/coder-paste --case zchat.zsh/chat-paste --case endgame/endgame-world --case zcoder.zsh/coder-wide-layout)
for pass in first repeat; do
 pair=("$a" "$b")
 if [[ $pass == repeat ]]; then pair=("$b" "$a"); fi
 "${bench[@]}" "${pair[@]}" --samples 9 --output "$d/$pass.json" > "$d/$pass.log"
done
for other in pristine installed; do
 case $other in pristine) shell=$PWD/.work/rc0-release-baseline/Src/zsh;; installed) shell=/usr/local/psh/current/bin/psh;; esac
 "${bench[@]}" "$shell" "$b" --samples 5 "${focus[@]}" --output "$d/$other.json" > "$d/$other.log"
done
python3 Perf/memory-checkpoints.py --shell "$a" --shell "$b" "${paths[@]}" "${focus[@]}" --samples 5 --output "$d/memory.json" >"$d/memory.log"
for host in base installed candidate; do
 case $host in base) shell=$PWD/.work/round92/shared/runtime/bin/zsh;; installed) shell=/usr/local/psh/current/bin/psh;; candidate) shell=$d/runtime/bin/zsh;; esac
 pd=$w/profile-$host
 if [[ $host == candidate ]]; then pd=$d/profile; fi
 if [[ -s $pd/profile.json ]]; then continue; fi
 python3 Perf/profile-customer-release.py --shell "$shell" "${paths[@]}" --case zchat.zsh/chat-paste --case endgame/endgame-world --output "$pd" > "$d/profile-$host.log"
done
