set -eu
d="$PWD/.work/round94/$1"
shell="$d/runtime/bin/zsh"
python3 Packaging/check-ohmyzsh.py --candidate "$shell" --output "$d/ohmyzsh.json" > "$d/logs/ohmyzsh.log"
python3 Perf/check-convfloat-loaders.py --candidate "$shell" --output "$d/native.json" > "$d/logs/native.log"
make -C "$d/build" check > "$d/logs/check.log" 2>&1
for loc in C C.UTF-8; do
    env -i LC_ALL="$loc" PATH=/usr/bin:/bin "$shell" -df Vendor/zjson/tests/run.zsh >"$d/logs/zjson-$loc.log" 2>&1
done
