# Run from the repository root after building the release-profile core.
mkdir -p .work/round58/native
gcc -shared -fPIC -g -O2 -DHAVE_CONFIG_H -DMODULE -I.work/release-candidate/Src -ISrc Perf/lock-close-module.c -o .work/round58/native/lock_oracle.so
python3 Perf/check-lock-close.py --shell .work/release-candidate/Src/zsh --modules .work/release-runtime/lib/zsh/5.9.2 --native .work/round58/native --output .work/round58/native.json
