# Run from the repository root after the release-profile build.
# Preserve zpty-before.c from commit 35437d6 before modifying/rebuilding.
mkdir -p .work/round56/ubsan-before/zsh .work/round56/ubsan-after/zsh .work/round56/select-after/zsh .work/round56/pristine-ubsan/zsh
gcc -shared -fPIC -g -O1 -DHAVE_CONFIG_H -DMODULE -I.work/release-candidate/Src/Modules -I.work/release-candidate/Src -ISrc -ISrc/Zle -ISrc/Modules -fsanitize=undefined .work/round56/zpty-before.c -o .work/round56/ubsan-before/zsh/zpty.so
gcc -shared -fPIC -g -O1 -DHAVE_CONFIG_H -DMODULE -I.work/release-candidate/Src/Modules -I.work/release-candidate/Src -ISrc -ISrc/Zle -ISrc/Modules -fsanitize=undefined Src/Modules/zpty.c -o .work/round56/ubsan-after/zsh/zpty.so
python3 - <<'PY'
from pathlib import Path
source=Path('Src/Modules/zpty.c').read_text()
Path('.work/round56/zpty-select-after.c').write_text(source.replace('#include "zpty.pro"', '#include "zpty.pro"\n#undef HAVE_POLL', 1))
PY
gcc -shared -fPIC -g -O1 -DHAVE_CONFIG_H -DMODULE -I.work/release-candidate/Src/Modules -I.work/release-candidate/Src -ISrc -ISrc/Zle -ISrc/Modules -fsanitize=undefined .work/round56/zpty-select-after.c -o .work/round56/select-after/zsh/zpty.so
gcc -shared -fPIC -g -O1 -DHAVE_CONFIG_H -DMODULE -I.work/baseline/Src/Modules -I.work/baseline/Src -I.work/pristine/Src -I.work/pristine/Src/Zle -I.work/pristine/Src/Modules -fsanitize=undefined .work/pristine/Src/Modules/zpty.c -o .work/round56/pristine-ubsan/zsh/zpty.so
