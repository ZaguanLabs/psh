import sys,subprocess
from pathlib import Path
from contextlib import redirect_stdout
root=Path.cwd()
sys.path.insert(0,str(root/'Packaging'))
from compiler import compile_core
w=root/'.work/round98'/sys.argv[1]
with (w/'pipeline.log').open('w') as out, redirect_stdout(out):
 compile_core(root,w/'build',w,['./configure','--prefix='+str(w/'runtime'),'--enable-multibyte','--disable-zsh-debug','--enable-pcre'],8,'pgo-lto')
with (w/'logs/install.log').open('wb') as out:
 subprocess.run(['make','install'],cwd=w/'build',stdout=out,stderr=subprocess.STDOUT,check=True)
