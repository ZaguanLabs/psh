set -eu
w=$PWD/.work/round98
project=/home/stig/dev/ai/zaguan/labs/zcoder.zsh
ref=$PWD/.work/rc0-release-baseline/Src/zsh
for size in 10000 100000; do
    python3 - "$size" "$w" <<'PY'
from pathlib import Path
import sys
size, work = sys.argv[1:]
source = Path('Perf/results/round94/viewport-memory.py').resolve()
driver = source.read_text().replace('Path(__file__).resolve().parents[2]',
                                    'Path(' + repr(str(source.parents[2])) + ')')
driver = driver.replace('Path(__file__).resolve().with_name("viewport.zsh")',
                        'Path(' + repr(str(source.with_name('viewport.zsh'))) + ')')
driver = driver.replace('"10000", "wide"', f'"{int(size)}", "wide"')
driver = driver.replace('"Private_Dirty")', '"Private_Dirty", "status_VmHWM", "status_VmSize")')
Path(work, 'size-driver.py').write_text(driver)
PY
    python3 "$w/size-driver.py" --build "$w/a/zsh" "$w/probe/a" --build "$w/b/zsh" "$w/probe/b" --build "$ref" "$w/probe/pristine" --project "$project" --output "$w/size-$size.json"
done
