set -eu
w=$PWD/.work/round98
# Reuse round 94's viewport worker and sampling method across short and long inputs.
mkdir -p "$w/boundaries"
ln -sf "$PWD/Perf/results/round94/viewport.zsh" "$w/boundaries/viewport.zsh"
sed 's/\[(64, "ascii"), (10000, "ascii"), (10000, "wide")\]/[(n, "ascii") for n in (64, 1024, 4094, 4095, 4096, 4097, 8192, 10000)] + [(n, "wide") for n in (818, 819, 820, 1024, 10000)]/' Perf/results/round94/viewport.py > "$w/boundaries/viewport.py"
python3 "$w/boundaries/viewport.py" --shell "$w/b/zsh" --shell "$w/a/zsh" --project /home/stig/dev/ai/zaguan/labs/zcoder.zsh --cpu 13 --output "$w/boundaries.json"
