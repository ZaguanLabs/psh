mkdir -p .work/round59/ubsan/zsh
gcc -shared -fPIC -g -O1 -DHAVE_CONFIG_H -DMODULE -I.work/release-candidate/Src/Modules -I.work/release-candidate/Src -ISrc -ISrc/Zle -ISrc/Modules -fsanitize=undefined,float-cast-overflow -fno-sanitize-recover=all Src/Modules/system.c .work/release-candidate/Src/Modules/errnames..o -o .work/round59/ubsan/zsh/system.so
