"""Bounded observations only; not a latency benchmark or timeout-policy oracle."""
import hashlib,json,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parents[2]
rows=[]
for label,path in [('pristine','.work/baseline/Src/zsh'),('rc2','/usr/local/bin/psh'),('candidate','.work/release-candidate/Src/zsh')]:
 shell=(root/path).resolve()
 for value in ['1','4294967296','2147484']:
  proc=subprocess.Popen([str(shell),'-dfc','zmodload zsh/system; sysread -s 1 -t "$1"; print -r -- "$?:$REPLY"','probe',value],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  try:
   # Keep the writer open without data, then supply a byte.  Startup and
   # scheduling are deliberately not treated as timing measurements.
   time.sleep(.1)
   out,err=proc.communicate(b'X',timeout=2)
   rows.append(dict(build=label,shell=str(shell),sha256=hashlib.sha256(shell.read_bytes()).hexdigest(),timeout=value,status=proc.returncode,stdout=out.decode(),stderr=err.decode()))
  finally:
   if proc.poll() is None:
    proc.kill();proc.communicate()
for value in ['2147484','1e300']:
 shell=root/'.work/release-candidate/Src/zsh'
 code='module_path=("$1"); zmodload zsh/system || exit; sysread -s 1 -t "$2"'
 proc=subprocess.run([str(shell),'-dfc',code,'probe',str(root/'.work/round50/ubsan-after'),value],input=b'X',capture_output=True,timeout=2,env={'PATH':'/usr/bin:/bin','UBSAN_OPTIONS':'halt_on_error=1:exitcode=86'})
 rows.append(dict(build='instrumented-candidate',timeout=value,status=proc.returncode,stdout=proc.stdout.decode(),stderr=proc.stderr.decode()))
out=Path(__file__).with_name('timeout-observations.json');out.write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:print(row['build'],row['timeout'],row['status'],repr(row['stdout']),row['stderr'].strip())
