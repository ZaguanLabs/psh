# Run from the repository root after the release-profile build.
mkdir -p .work/round50/ubsan-before/zsh .work/round50/ubsan-after/zsh
git show 9250fb9:Src/Modules/system.c > .work/round50/system-before.c
gcc -shared -fPIC -g -O1 -DHAVE_CONFIG_H -DMODULE -I.work/release-candidate/Src/Modules -I.work/release-candidate/Src -ISrc -ISrc/Zle -ISrc/Modules -fsanitize=undefined,float-cast-overflow .work/round50/system-before.c .work/release-candidate/Src/Modules/errnames..o -o .work/round50/ubsan-before/zsh/system.so
python3 Perf/check-systell.py --shell .work/release-candidate/Src/zsh --modules .work/round50/ubsan-before --output .work/round50/ubsan-before.json
gcc -shared -fPIC -g -O1 -DHAVE_CONFIG_H -DMODULE -I.work/release-candidate/Src/Modules -I.work/release-candidate/Src -ISrc -ISrc/Zle -ISrc/Modules -fsanitize=undefined,float-cast-overflow Src/Modules/system.c .work/release-candidate/Src/Modules/errnames..o -o .work/round50/ubsan-after/zsh/system.so
python3 Perf/check-systell.py --shell .work/release-candidate/Src/zsh --modules .work/round50/ubsan-after --output .work/round50/ubsan-after.json
