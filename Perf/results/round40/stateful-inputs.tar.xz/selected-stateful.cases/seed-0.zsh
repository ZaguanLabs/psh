emulate -R zsh
setopt extendedglob
typeset -a a=(one two three)
typeset -A h=(first original)
typeset s='original'
integer total=0
psh-inner() { local -a a=(inner nested); local s=inner; print -r -- scope:$1:${(qqq)a}:${(qqq)s}; a[2]=changed; }
psh-outer() { emulate -L zsh; local -a a=(local outer); local s=outer; local -A h=(scope local); psh-inner $1; unset a; local -i a=17; (( a+=3 )); print -r -- restored:$a:$s:$h[scope]; }
psh-recover() { local -i n=7; ( eval '(( 1 / 0 ))' ); local status_code=$?; (( n+=5 )); print -r -- recovery:$status_code:$n; }
h[key2]='a'\''b'
print -r -- step:0:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:1:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_111
print -r -- step:2:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[9]='one
two'
print -r -- step:3:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key9]='plain'
print -r -- step:4:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 5
print -r -- step:5:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='one
two'; print -r -- scalar:${(qqq)s[1,6]}:${(qqq)s//a/A}
print -r -- step:6:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_133='界'; psh-outer 7
print -r -- step:7:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'']}:${(qqq)a[-1]}
print -r -- step:8:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key31]"
print -r -- step:9:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[21]=()
print -r -- step:10:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:11:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('one
two')
print -r -- step:12:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key6]='*[x]?'
print -r -- step:13:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_170='one
two'; psh-outer 14
print -r -- step:14:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 15
print -r -- step:15:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_123
print -r -- step:16:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[12]='a b'
print -r -- step:17:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('')
print -r -- step:18:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('one
two')
print -r -- step:19:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[18]=()
print -r -- step:20:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 21
print -r -- step:21:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_59
print -r -- step:22:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[22]=()
print -r -- step:23:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'']}:${(qqq)a[-1]}
print -r -- step:24:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key10]"
print -r -- step:25:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:26:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_37
print -r -- step:27:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_61
print -r -- step:28:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a'\''b')
print -r -- step:29:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[2]=''
print -r -- step:30:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'plain']}:${(qqq)a[-1]}
print -r -- step:31:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_51
print -r -- step:32:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a b')
print -r -- step:33:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[23]='a b'
print -r -- step:34:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_51
print -r -- step:35:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key16]"
print -r -- step:36:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:37:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key10]"
print -r -- step:38:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_226
print -r -- step:39:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(52*3+40)%97 ))
print -r -- step:40:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='one
two'; print -r -- scalar:${(qqq)s[1,5]}:${(qqq)s//a/A}
print -r -- step:41:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'café']}:${(qqq)a[-1]}
print -r -- step:42:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_143='plain'; psh-outer 43
print -r -- step:43:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key30]"
print -r -- step:44:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a b']}:${(qqq)a[-1]}
print -r -- step:45:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(10*3+46)%97 ))
print -r -- step:46:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[13]=''
print -r -- step:47:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='界'; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:48:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:49:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('')
print -r -- step:50:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_249='a b'; psh-outer 51
print -r -- step:51:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 52
print -r -- step:52:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('界' 'one
two' 'plain' 'café' '' 'a'\''b')
print -r -- step:53:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[21]=()
print -r -- step:54:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[1]=()
print -r -- step:55:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key19]='plain'
print -r -- step:56:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='café'; print -r -- scalar:${(qqq)s[1,2]}:${(qqq)s//a/A}
print -r -- step:57:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:58:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(66*3+59)%97 ))
print -r -- step:59:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key9]='*[x]?'
print -r -- step:60:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[3]=()
print -r -- step:61:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_21
print -r -- step:62:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key27]"
print -r -- step:63:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='one
two'; print -r -- scalar:${(qqq)s[1,5]}:${(qqq)s//a/A}
print -r -- step:64:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key9]=''
print -r -- step:65:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'*[x]?']}:${(qqq)a[-1]}
print -r -- step:66:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('café' 'café' 'a b' '*[x]?')
print -r -- step:67:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a'\''b')
print -r -- step:68:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key3]='x:y'
print -r -- step:69:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='café'; print -r -- scalar:${(qqq)s[1,6]}:${(qqq)s//a/A}
print -r -- step:70:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a b')
print -r -- step:71:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key30]"
print -r -- step:72:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('*[x]?')
print -r -- step:73:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key2]='x:y'
print -r -- step:74:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(72*3+75)%97 ))
print -r -- step:75:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:76:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('' 'plain' 'a'\''b' 'one
two' 'one
two' 'a b')
print -r -- step:77:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='x:y'; print -r -- scalar:${(qqq)s[1,2]}:${(qqq)s//a/A}
print -r -- step:78:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_85
print -r -- step:79:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a'\''b')
print -r -- step:80:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:81:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='界'; print -r -- scalar:${(qqq)s[1,5]}:${(qqq)s//a/A}
print -r -- step:82:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_74
print -r -- step:83:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='plain'; print -r -- scalar:${(qqq)s[1,6]}:${(qqq)s//a/A}
print -r -- step:84:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_249
print -r -- step:85:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_253='café'; psh-outer 86
print -r -- step:86:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(85*3+87)%97 ))
print -r -- step:87:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key0]"
print -r -- step:88:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_75='*[x]?'; psh-outer 89
print -r -- step:89:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_150
print -r -- step:90:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_20='x:y'; psh-outer 91
print -r -- step:91:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('' 'x:y' '*[x]?' 'café')
print -r -- step:92:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_195='café'; psh-outer 93
print -r -- step:93:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(66*3+94)%97 ))
print -r -- step:94:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key13]='plain'
print -r -- step:95:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:96:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(0*3+97)%97 ))
print -r -- step:97:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key16]"
print -r -- step:98:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key16]='plain'
print -r -- step:99:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('café' '界')
print -r -- step:100:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('a'\''b' 'café' 'x:y' 'plain' 'café' '*[x]?' 'a'\''b')
print -r -- step:101:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 102
print -r -- step:102:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:103:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_67
print -r -- step:104:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[7]=()
print -r -- step:105:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('*[x]?' 'plain' 'a b' 'café' 'a'\''b' 'a b' 'plain')
print -r -- step:106:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:107:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:108:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:109:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 110
print -r -- step:110:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[2]=()
print -r -- step:111:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('plain')
print -r -- step:112:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('café')
print -r -- step:113:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('plain')
print -r -- step:114:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:115:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('*[x]?' 'a b' 'plain' '*[x]?' 'plain' 'plain' '*[x]?')
print -r -- step:116:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[23]=''
print -r -- step:117:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('')
print -r -- step:118:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[14]=()
print -r -- step:119:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key18]"
print -r -- step:120:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[15]=''
print -r -- step:121:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key30]"
print -r -- step:122:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[9]=()
print -r -- step:123:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key30]='*[x]?'
print -r -- step:124:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_41
print -r -- step:125:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='plain'; print -r -- scalar:${(qqq)s[1,3]}:${(qqq)s//a/A}
print -r -- step:126:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_124='café'; psh-outer 127
print -r -- step:127:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key18]"
print -r -- step:128:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_10
print -r -- step:129:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[5]='a'\''b'
print -r -- step:130:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a'\''b']}:${(qqq)a[-1]}
print -r -- step:131:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(45*3+132)%97 ))
print -r -- step:132:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(47*3+133)%97 ))
print -r -- step:133:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='one
two'; print -r -- scalar:${(qqq)s[1,1]}:${(qqq)s//a/A}
print -r -- step:134:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[21]=()
print -r -- step:135:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('*[x]?')
print -r -- step:136:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('café')
print -r -- step:137:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='one
two'; print -r -- scalar:${(qqq)s[1,3]}:${(qqq)s//a/A}
print -r -- step:138:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[28]=()
print -r -- step:139:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key9]"
print -r -- step:140:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:141:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'界']}:${(qqq)a[-1]}
print -r -- step:142:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[30]=()
print -r -- step:143:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_79='a b'; psh-outer 144
print -r -- step:144:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(63*3+145)%97 ))
print -r -- step:145:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(2*3+146)%97 ))
print -r -- step:146:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('a'\''b' 'one
two' 'a'\''b' 'x:y')
print -r -- step:147:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key22]='plain'
print -r -- step:148:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('界')
print -r -- step:149:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a b')
print -r -- step:150:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('one
two')
print -r -- step:151:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_68='a'\''b'; psh-outer 152
print -r -- step:152:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='one
two'; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:153:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key28]"
print -r -- step:154:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'café']}:${(qqq)a[-1]}
print -r -- step:155:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_239
print -r -- step:156:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(60*3+157)%97 ))
print -r -- step:157:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 158
print -r -- step:158:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(7*3+159)%97 ))
print -r -- step:159:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'x:y']}:${(qqq)a[-1]}
print -r -- step:160:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('x:y' 'a'\''b' '' 'one
two' 'plain')
print -r -- step:161:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key0]"
print -r -- step:162:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key0]=''
print -r -- step:163:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:164:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a b'; print -r -- scalar:${(qqq)s[1,8]}:${(qqq)s//a/A}
print -r -- step:165:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key10]"
print -r -- step:166:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 167
print -r -- step:167:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[21]=()
print -r -- step:168:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:169:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a'\''b'; print -r -- scalar:${(qqq)s[1,4]}:${(qqq)s//a/A}
print -r -- step:170:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_25
print -r -- step:171:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(10*3+172)%97 ))
print -r -- step:172:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'café']}:${(qqq)a[-1]}
print -r -- step:173:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_44
print -r -- step:174:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='one
two'; print -r -- scalar:${(qqq)s[1,8]}:${(qqq)s//a/A}
print -r -- step:175:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 176
print -r -- step:176:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key13]"
print -r -- step:177:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('*[x]?' '')
print -r -- step:178:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a b')
print -r -- step:179:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_113='a'\''b'; psh-outer 180
print -r -- step:180:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_52
print -r -- step:181:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_233='plain'; psh-outer 182
print -r -- step:182:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_22='*[x]?'; psh-outer 183
print -r -- step:183:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[24]=()
print -r -- step:184:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[23]=()
print -r -- step:185:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_196='a b'; psh-outer 186
print -r -- step:186:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a b']}:${(qqq)a[-1]}
print -r -- step:187:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_37='界'; psh-outer 188
print -r -- step:188:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'']}:${(qqq)a[-1]}
print -r -- step:189:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 190
print -r -- step:190:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('x:y')
print -r -- step:191:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:192:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 193
print -r -- step:193:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('界' 'x:y')
print -r -- step:194:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key17]"
print -r -- step:195:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_146='*[x]?'; psh-outer 196
print -r -- step:196:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:197:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key16]='x:y'
print -r -- step:198:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_50
print -r -- step:199:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[27]=()
print -r -- step:200:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('a'\''b')
print -r -- step:201:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[8]=()
print -r -- step:202:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'one
two']}:${(qqq)a[-1]}
print -r -- step:203:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(41*3+204)%97 ))
print -r -- step:204:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key30]='界'
print -r -- step:205:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_167='café'; psh-outer 206
print -r -- step:206:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='*[x]?'; print -r -- scalar:${(qqq)s[1,3]}:${(qqq)s//a/A}
print -r -- step:207:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:208:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[32]=()
print -r -- step:209:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key24]"
print -r -- step:210:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_13
print -r -- step:211:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 212
print -r -- step:212:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_83='a b'; psh-outer 213
print -r -- step:213:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'x:y']}:${(qqq)a[-1]}
print -r -- step:214:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_205
print -r -- step:215:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='界'; print -r -- scalar:${(qqq)s[1,1]}:${(qqq)s//a/A}
print -r -- step:216:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'界']}:${(qqq)a[-1]}
print -r -- step:217:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(92*3+218)%97 ))
print -r -- step:218:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(20*3+219)%97 ))
print -r -- step:219:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_29
print -r -- step:220:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 221
print -r -- step:221:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=()
print -r -- step:222:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('a'\''b' 'café' '界' 'x:y' 'a'\''b')
print -r -- step:223:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[23]='café'
print -r -- step:224:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('a b' 'one
two' 'one
two' 'x:y' '' 'plain')
print -r -- step:225:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('café' 'one
two' 'café' 'plain' '*[x]?' '界' 'café' '界')
print -r -- step:226:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'']}:${(qqq)a[-1]}
print -r -- step:227:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_234
print -r -- step:228:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key16]"
print -r -- step:229:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 230
print -r -- step:230:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(19*3+231)%97 ))
print -r -- step:231:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[16]='x:y'
print -r -- step:232:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:233:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key0]='x:y'
print -r -- step:234:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('one
two' 'a b' '' 'x:y' 'a'\''b' 'plain' 'a'\''b' '*[x]?')
print -r -- step:235:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key1]='x:y'
print -r -- step:236:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(97*3+237)%97 ))
print -r -- step:237:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key24]='界'
print -r -- step:238:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:239:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[23]='界'
print -r -- step:240:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_79
print -r -- step:241:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(37*3+242)%97 ))
print -r -- step:242:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_220
print -r -- step:243:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_22
print -r -- step:244:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('a b' '界' 'plain' 'one
two' 'a'\''b' 'a b' 'café')
print -r -- step:245:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(81*3+246)%97 ))
print -r -- step:246:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:247:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key19]='a'\''b'
print -r -- step:248:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key17]=''
print -r -- step:249:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[21]=()
print -r -- step:250:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:251:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key24]"
print -r -- step:252:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(78*3+253)%97 ))
print -r -- step:253:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_81='界'; psh-outer 254
print -r -- step:254:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('界' 'a b' 'café')
print -r -- step:255:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[5]=()
print -r -- step:256:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[7]='x:y'
print -r -- step:257:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(50*3+258)%97 ))
print -r -- step:258:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:259:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key5]='*[x]?'
print -r -- step:260:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:261:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a b'; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:262:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key29]"
print -r -- step:263:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('x:y' 'one
two' 'café' '' 'plain' '*[x]?')
print -r -- step:264:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[1]=()
print -r -- step:265:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key2]"
print -r -- step:266:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[21]=''
print -r -- step:267:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_75
print -r -- step:268:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[20]='a'\''b'
print -r -- step:269:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'café']}:${(qqq)a[-1]}
print -r -- step:270:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[3]=''
print -r -- step:271:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_89='*[x]?'; psh-outer 272
print -r -- step:272:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key16]"
print -r -- step:273:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[17]='a b'
print -r -- step:274:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(74*3+275)%97 ))
print -r -- step:275:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('café')
print -r -- step:276:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:277:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(17*3+278)%97 ))
print -r -- step:278:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_175='x:y'; psh-outer 279
print -r -- step:279:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s=''; print -r -- scalar:${(qqq)s[1,6]}:${(qqq)s//a/A}
print -r -- step:280:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_185='x:y'; psh-outer 281
print -r -- step:281:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('café' '')
print -r -- step:282:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='*[x]?'; print -r -- scalar:${(qqq)s[1,1]}:${(qqq)s//a/A}
print -r -- step:283:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_86
print -r -- step:284:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('*[x]?' 'a b' 'a b' 'x:y' 'a'\''b' 'café' '')
print -r -- step:285:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='x:y'; print -r -- scalar:${(qqq)s[1,2]}:${(qqq)s//a/A}
print -r -- step:286:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('' 'café' 'a'\''b' '' '*[x]?')
print -r -- step:287:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('x:y')
print -r -- step:288:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('plain' 'plain' '*[x]?' '*[x]?' 'plain' 'x:y' '' 'café')
print -r -- step:289:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('*[x]?' 'café' 'one
two' 'café' 'café' 'café')
print -r -- step:290:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('a'\''b' '' '界' '界' 'a b' '*[x]?' 'café')
print -r -- step:291:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[23]='界'
print -r -- step:292:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_70
print -r -- step:293:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_2
print -r -- step:294:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=()
print -r -- step:295:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('café')
print -r -- step:296:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='café'; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:297:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key8]"
print -r -- step:298:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('one
two')
print -r -- step:299:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('café')
print -r -- step:300:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 301
print -r -- step:301:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[15]=()
print -r -- step:302:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key4]='x:y'
print -r -- step:303:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_242
print -r -- step:304:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_164
print -r -- step:305:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[7]='a'\''b'
print -r -- step:306:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a'\''b']}:${(qqq)a[-1]}
print -r -- step:307:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a'\''b']}:${(qqq)a[-1]}
print -r -- step:308:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[30]='x:y'
print -r -- step:309:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[31]='*[x]?'
print -r -- step:310:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key23]"
print -r -- step:311:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(66*3+312)%97 ))
print -r -- step:312:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[13]=''
print -r -- step:313:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(5*3+314)%97 ))
print -r -- step:314:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(52*3+315)%97 ))
print -r -- step:315:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key13]"
print -r -- step:316:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_182
print -r -- step:317:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_203
print -r -- step:318:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:319:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[9]='a'\''b'
print -r -- step:320:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('café' 'x:y' '*[x]?' 'a b' '*[x]?' 'plain' 'a'\''b' 'a b')
print -r -- step:321:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_74='café'; psh-outer 322
print -r -- step:322:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a'\''b'; print -r -- scalar:${(qqq)s[1,6]}:${(qqq)s//a/A}
print -r -- step:323:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a'\''b'; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:324:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('plain' '界' 'one
two' 'plain' 'a b' 'café' 'a'\''b' 'plain')
print -r -- step:325:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key7]"
print -r -- step:326:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(57*3+327)%97 ))
print -r -- step:327:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:328:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:329:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(21*3+330)%97 ))
print -r -- step:330:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 331
print -r -- step:331:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_68
print -r -- step:332:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_27
print -r -- step:333:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key25]"
print -r -- step:334:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 335
print -r -- step:335:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_201='plain'; psh-outer 336
print -r -- step:336:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[17]=()
print -r -- step:337:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key10]='one
two'
print -r -- step:338:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('café')
print -r -- step:339:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_47='x:y'; psh-outer 340
print -r -- step:340:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a b')
print -r -- step:341:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:342:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(17*3+343)%97 ))
print -r -- step:343:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('one
two' 'x:y' 'plain' 'x:y' 'one
two' '*[x]?')
print -r -- step:344:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[7]=()
print -r -- step:345:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key19]='界'
print -r -- step:346:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key31]"
print -r -- step:347:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('one
two')
print -r -- step:348:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a b']}:${(qqq)a[-1]}
print -r -- step:349:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[25]=()
print -r -- step:350:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(45*3+351)%97 ))
print -r -- step:351:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:352:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_241='plain'; psh-outer 353
print -r -- step:353:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='界'; print -r -- scalar:${(qqq)s[1,5]}:${(qqq)s//a/A}
print -r -- step:354:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('*[x]?')
print -r -- step:355:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 356
print -r -- step:356:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'café']}:${(qqq)a[-1]}
print -r -- step:357:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[22]=()
print -r -- step:358:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 359
print -r -- step:359:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(51*3+360)%97 ))
print -r -- step:360:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[20]=()
print -r -- step:361:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 362
print -r -- step:362:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='*[x]?'; print -r -- scalar:${(qqq)s[1,1]}:${(qqq)s//a/A}
print -r -- step:363:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key5]=''
print -r -- step:364:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('界')
print -r -- step:365:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[24]=()
print -r -- step:366:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_2=''; psh-outer 367
print -r -- step:367:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('café')
print -r -- step:368:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_212='x:y'; psh-outer 369
print -r -- step:369:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[12]=()
print -r -- step:370:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:371:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s=''; print -r -- scalar:${(qqq)s[1,1]}:${(qqq)s//a/A}
print -r -- step:372:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a b']}:${(qqq)a[-1]}
print -r -- step:373:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(17*3+374)%97 ))
print -r -- step:374:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('one
two')
print -r -- step:375:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'plain']}:${(qqq)a[-1]}
print -r -- step:376:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[9]=()
print -r -- step:377:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_61='*[x]?'; psh-outer 378
print -r -- step:378:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('one
two')
print -r -- step:379:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[29]='one
two'
print -r -- step:380:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='x:y'; print -r -- scalar:${(qqq)s[1,5]}:${(qqq)s//a/A}
print -r -- step:381:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[6]=()
print -r -- step:382:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 383
print -r -- step:383:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a'\''b']}:${(qqq)a[-1]}
print -r -- step:384:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[26]=()
print -r -- step:385:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 386
print -r -- step:386:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 387
print -r -- step:387:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_76
print -r -- step:388:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key12]='one
two'
print -r -- step:389:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[8]='one
two'
print -r -- step:390:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_82
print -r -- step:391:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='x:y'; print -r -- scalar:${(qqq)s[1,8]}:${(qqq)s//a/A}
print -r -- step:392:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('one
two' '界' '*[x]?' 'café' 'one
two')
print -r -- step:393:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(88*3+394)%97 ))
print -r -- step:394:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('x:y' '*[x]?' 'one
two')
print -r -- step:395:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('界' 'x:y')
print -r -- step:396:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(81*3+397)%97 ))
print -r -- step:397:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(24*3+398)%97 ))
print -r -- step:398:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'café']}:${(qqq)a[-1]}
print -r -- step:399:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(40*3+400)%97 ))
print -r -- step:400:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[5]=()
print -r -- step:401:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 402
print -r -- step:402:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'one
two']}:${(qqq)a[-1]}
print -r -- step:403:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[2]=()
print -r -- step:404:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_107='plain'; psh-outer 405
print -r -- step:405:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key31]=''
print -r -- step:406:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_252
print -r -- step:407:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_184
print -r -- step:408:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:409:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[2]='界'
print -r -- step:410:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_228
print -r -- step:411:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a b'; print -r -- scalar:${(qqq)s[1,6]}:${(qqq)s//a/A}
print -r -- step:412:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('*[x]?' 'x:y')
print -r -- step:413:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key27]"
print -r -- step:414:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a'\''b'; print -r -- scalar:${(qqq)s[1,3]}:${(qqq)s//a/A}
print -r -- step:415:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'café']}:${(qqq)a[-1]}
print -r -- step:416:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(34*3+417)%97 ))
print -r -- step:417:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key7]"
print -r -- step:418:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a b']}:${(qqq)a[-1]}
print -r -- step:419:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_7='one
two'; psh-outer 420
print -r -- step:420:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(33*3+421)%97 ))
print -r -- step:421:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('*[x]?')
print -r -- step:422:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key4]='one
two'
print -r -- step:423:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 424
print -r -- step:424:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('')
print -r -- step:425:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'one
two']}:${(qqq)a[-1]}
print -r -- step:426:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_224
print -r -- step:427:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'*[x]?']}:${(qqq)a[-1]}
print -r -- step:428:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 429
print -r -- step:429:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_0='*[x]?'; psh-outer 430
print -r -- step:430:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'plain']}:${(qqq)a[-1]}
print -r -- step:431:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_7
print -r -- step:432:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a b']}:${(qqq)a[-1]}
print -r -- step:433:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 434
print -r -- step:434:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('plain')
print -r -- step:435:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[30]='plain'
print -r -- step:436:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(89*3+437)%97 ))
print -r -- step:437:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('plain' '*[x]?' '*[x]?' 'one
two')
print -r -- step:438:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a b']}:${(qqq)a[-1]}
print -r -- step:439:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_28
print -r -- step:440:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_115
print -r -- step:441:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 442
print -r -- step:442:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[28]='plain'
print -r -- step:443:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'one
two']}:${(qqq)a[-1]}
print -r -- step:444:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[25]=()
print -r -- step:445:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[20]='plain'
print -r -- step:446:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:447:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_126='*[x]?'; psh-outer 448
print -r -- step:448:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='x:y'; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:449:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'x:y']}:${(qqq)a[-1]}
print -r -- step:450:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[23]=()
print -r -- step:451:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:452:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_13='café'; psh-outer 453
print -r -- step:453:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'café']}:${(qqq)a[-1]}
print -r -- step:454:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_86
print -r -- step:455:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'界']}:${(qqq)a[-1]}
print -r -- step:456:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='x:y'; print -r -- scalar:${(qqq)s[1,3]}:${(qqq)s//a/A}
print -r -- step:457:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a'\''b'; print -r -- scalar:${(qqq)s[1,8]}:${(qqq)s//a/A}
print -r -- step:458:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_5='plain'; psh-outer 459
print -r -- step:459:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'plain']}:${(qqq)a[-1]}
print -r -- step:460:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a'\''b'; print -r -- scalar:${(qqq)s[1,6]}:${(qqq)s//a/A}
print -r -- step:461:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:462:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=()
print -r -- step:463:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[5]=()
print -r -- step:464:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('*[x]?' '*[x]?')
print -r -- step:465:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[20]='*[x]?'
print -r -- step:466:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_203
print -r -- step:467:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 468
print -r -- step:468:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:469:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='*[x]?'; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:470:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[20]=()
print -r -- step:471:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_85='a'\''b'; psh-outer 472
print -r -- step:472:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key30]"
print -r -- step:473:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 474
print -r -- step:474:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key12]='one
two'
print -r -- step:475:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[5]=()
print -r -- step:476:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[17]=()
print -r -- step:477:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_137
print -r -- step:478:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_85
print -r -- step:479:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 480
print -r -- step:480:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_221
print -r -- step:481:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('a b' '*[x]?' '界' 'a'\''b' '界' '*[x]?' 'café' 'café')
print -r -- step:482:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_116
print -r -- step:483:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_16
print -r -- step:484:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key26]='café'
print -r -- step:485:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key3]"
print -r -- step:486:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 487
print -r -- step:487:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(9*3+488)%97 ))
print -r -- step:488:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_132='x:y'; psh-outer 489
print -r -- step:489:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='one
two'; print -r -- scalar:${(qqq)s[1,3]}:${(qqq)s//a/A}
print -r -- step:490:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_57
print -r -- step:491:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(93*3+492)%97 ))
print -r -- step:492:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key16]='plain'
print -r -- step:493:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=()
print -r -- step:494:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s=''; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:495:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(17*3+496)%97 ))
print -r -- step:496:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('a'\''b' '' '')
print -r -- step:497:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a'\''b'; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:498:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_74='one
two'; psh-outer 499
print -r -- step:499:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_86
print -r -- step:500:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key18]='plain'
print -r -- step:501:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(1*3+502)%97 ))
print -r -- step:502:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(36*3+503)%97 ))
print -r -- step:503:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('café')
print -r -- step:504:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[1]='*[x]?'
print -r -- step:505:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key5]"
print -r -- step:506:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key28]"
print -r -- step:507:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('x:y')
print -r -- step:508:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:509:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_37='a'\''b'; psh-outer 510
print -r -- step:510:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_160='界'; psh-outer 511
print -r -- step:511:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[5]='café'
print -r -- step:512:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(8*3+513)%97 ))
print -r -- step:513:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key19]"
print -r -- step:514:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'x:y']}:${(qqq)a[-1]}
print -r -- step:515:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:516:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:517:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[22]=()
print -r -- step:518:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key7]"
print -r -- step:519:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_57='a'\''b'; psh-outer 520
print -r -- step:520:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key2]"
print -r -- step:521:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 522
print -r -- step:522:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:523:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(92*3+524)%97 ))
print -r -- step:524:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_84='café'; psh-outer 525
print -r -- step:525:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[19]=()
print -r -- step:526:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_226
print -r -- step:527:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_73
print -r -- step:528:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[28]=()
print -r -- step:529:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[25]=()
print -r -- step:530:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_190='界'; psh-outer 531
print -r -- step:531:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_74
print -r -- step:532:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:533:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 534
print -r -- step:534:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_183
print -r -- step:535:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[6]=()
print -r -- step:536:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_103='a b'; psh-outer 537
print -r -- step:537:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'*[x]?']}:${(qqq)a[-1]}
print -r -- step:538:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[3]=()
print -r -- step:539:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key5]='café'
print -r -- step:540:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='one
two'; print -r -- scalar:${(qqq)s[1,6]}:${(qqq)s//a/A}
print -r -- step:541:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('café' 'a b' 'one
two' 'x:y' 'a b')
print -r -- step:542:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key30]"
print -r -- step:543:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:544:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'plain']}:${(qqq)a[-1]}
print -r -- step:545:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('a b')
print -r -- step:546:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:547:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key17]='one
two'
print -r -- step:548:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[12]='café'
print -r -- step:549:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 550
print -r -- step:550:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[10]=()
print -r -- step:551:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[9]='plain'
print -r -- step:552:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_245='界'; psh-outer 553
print -r -- step:553:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'café']}:${(qqq)a[-1]}
print -r -- step:554:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[15]='a b'
print -r -- step:555:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[1]='界'
print -r -- step:556:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_163='café'; psh-outer 557
print -r -- step:557:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key29]"
print -r -- step:558:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(90*3+559)%97 ))
print -r -- step:559:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 560
print -r -- step:560:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[23]=()
print -r -- step:561:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[26]='a b'
print -r -- step:562:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_70='a'\''b'; psh-outer 563
print -r -- step:563:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key27]='x:y'
print -r -- step:564:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'one
two']}:${(qqq)a[-1]}
print -r -- step:565:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key28]"
print -r -- step:566:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a'\''b'; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:567:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(4*3+568)%97 ))
print -r -- step:568:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[29]=()
print -r -- step:569:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('x:y')
print -r -- step:570:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_238='plain'; psh-outer 571
print -r -- step:571:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[3]=()
print -r -- step:572:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='界'; print -r -- scalar:${(qqq)s[1,2]}:${(qqq)s//a/A}
print -r -- step:573:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[14]=()
print -r -- step:574:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('x:y')
print -r -- step:575:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_220='one
two'; psh-outer 576
print -r -- step:576:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(80*3+577)%97 ))
print -r -- step:577:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:578:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 579
print -r -- step:579:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[14]='界'
print -r -- step:580:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('界')
print -r -- step:581:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key25]"
print -r -- step:582:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 583
print -r -- step:583:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[6]='*[x]?'
print -r -- step:584:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 585
print -r -- step:585:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a b']}:${(qqq)a[-1]}
print -r -- step:586:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key20]"
print -r -- step:587:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[24]=()
print -r -- step:588:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a b'; print -r -- scalar:${(qqq)s[1,1]}:${(qqq)s//a/A}
print -r -- step:589:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key4]='café'
print -r -- step:590:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key31]"
print -r -- step:591:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key27]='café'
print -r -- step:592:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[8]='界'
print -r -- step:593:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('x:y' 'plain' '*[x]?' 'plain')
print -r -- step:594:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_21='plain'; psh-outer 595
print -r -- step:595:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key29]=''
print -r -- step:596:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[25]=()
print -r -- step:597:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(80*3+598)%97 ))
print -r -- step:598:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[1]='界'
print -r -- step:599:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('café')
print -r -- step:600:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key6]='plain'
print -r -- step:601:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('café')
print -r -- step:602:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key22]"
print -r -- step:603:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('界' '界' 'plain' 'café')
print -r -- step:604:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key28]"
print -r -- step:605:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_66
print -r -- step:606:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key12]='*[x]?'
print -r -- step:607:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[29]=()
print -r -- step:608:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key5]"
print -r -- step:609:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='café'; print -r -- scalar:${(qqq)s[1,8]}:${(qqq)s//a/A}
print -r -- step:610:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 611
print -r -- step:611:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('plain' 'a'\''b' 'a b' '界')
print -r -- step:612:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_206='x:y'; psh-outer 613
print -r -- step:613:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[32]='café'
print -r -- step:614:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key21]=''
print -r -- step:615:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key27]='plain'
print -r -- step:616:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='*[x]?'; print -r -- scalar:${(qqq)s[1,3]}:${(qqq)s//a/A}
print -r -- step:617:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:618:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(45*3+619)%97 ))
print -r -- step:619:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key26]"
print -r -- step:620:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[6]='plain'
print -r -- step:621:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(61*3+622)%97 ))
print -r -- step:622:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='界'; print -r -- scalar:${(qqq)s[1,1]}:${(qqq)s//a/A}
print -r -- step:623:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key19]='a b'
print -r -- step:624:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('' 'plain')
print -r -- step:625:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[22]=()
print -r -- step:626:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key29]='界'
print -r -- step:627:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='one
two'; print -r -- scalar:${(qqq)s[1,1]}:${(qqq)s//a/A}
print -r -- step:628:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key6]"
print -r -- step:629:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_154='界'; psh-outer 630
print -r -- step:630:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'plain']}:${(qqq)a[-1]}
print -r -- step:631:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(21*3+632)%97 ))
print -r -- step:632:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 633
print -r -- step:633:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a b']}:${(qqq)a[-1]}
print -r -- step:634:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('')
print -r -- step:635:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(98*3+636)%97 ))
print -r -- step:636:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a'\''b']}:${(qqq)a[-1]}
print -r -- step:637:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(76*3+638)%97 ))
print -r -- step:638:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='one
two'; print -r -- scalar:${(qqq)s[1,1]}:${(qqq)s//a/A}
print -r -- step:639:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key18]"
print -r -- step:640:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(97*3+641)%97 ))
print -r -- step:641:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key22]='x:y'
print -r -- step:642:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 643
print -r -- step:643:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 644
print -r -- step:644:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a b')
print -r -- step:645:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='x:y'; print -r -- scalar:${(qqq)s[1,6]}:${(qqq)s//a/A}
print -r -- step:646:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 647
print -r -- step:647:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key28]"
print -r -- step:648:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('')
print -r -- step:649:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'x:y']}:${(qqq)a[-1]}
print -r -- step:650:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[26]=()
print -r -- step:651:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_244='plain'; psh-outer 652
print -r -- step:652:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_151
print -r -- step:653:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a'\''b')
print -r -- step:654:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s=''; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:655:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 656
print -r -- step:656:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(36*3+657)%97 ))
print -r -- step:657:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(55*3+658)%97 ))
print -r -- step:658:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_189='a'\''b'; psh-outer 659
print -r -- step:659:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key10]"
print -r -- step:660:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 661
print -r -- step:661:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key14]"
print -r -- step:662:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_173
print -r -- step:663:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('café')
print -r -- step:664:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[12]=()
print -r -- step:665:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(55*3+666)%97 ))
print -r -- step:666:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 667
print -r -- step:667:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 668
print -r -- step:668:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 669
print -r -- step:669:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a b'; print -r -- scalar:${(qqq)s[1,1]}:${(qqq)s//a/A}
print -r -- step:670:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a b')
print -r -- step:671:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 672
print -r -- step:672:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a b')
print -r -- step:673:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:674:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key0]='plain'
print -r -- step:675:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=()
print -r -- step:676:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(10*3+677)%97 ))
print -r -- step:677:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:678:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_59
print -r -- step:679:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='界'; print -r -- scalar:${(qqq)s[1,2]}:${(qqq)s//a/A}
print -r -- step:680:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_86='plain'; psh-outer 681
print -r -- step:681:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key8]"
print -r -- step:682:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(64*3+683)%97 ))
print -r -- step:683:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'']}:${(qqq)a[-1]}
print -r -- step:684:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_200='a'\''b'; psh-outer 685
print -r -- step:685:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[16]='a b'
print -r -- step:686:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key18]"
print -r -- step:687:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=()
print -r -- step:688:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(17*3+689)%97 ))
print -r -- step:689:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'café']}:${(qqq)a[-1]}
print -r -- step:690:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key17]='x:y'
print -r -- step:691:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(44*3+692)%97 ))
print -r -- step:692:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_253='*[x]?'; psh-outer 693
print -r -- step:693:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[17]=()
print -r -- step:694:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:695:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:696:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(42*3+697)%97 ))
print -r -- step:697:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:698:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key10]='a'\''b'
print -r -- step:699:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key5]"
print -r -- step:700:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[1]=()
print -r -- step:701:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_58='café'; psh-outer 702
print -r -- step:702:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_37
print -r -- step:703:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key2]='a'\''b'
print -r -- step:704:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key10]"
print -r -- step:705:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_101
print -r -- step:706:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_230=''; psh-outer 707
print -r -- step:707:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('*[x]?')
print -r -- step:708:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[27]=''
print -r -- step:709:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:710:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s=''; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:711:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='café'; print -r -- scalar:${(qqq)s[1,8]}:${(qqq)s//a/A}
print -r -- step:712:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'界']}:${(qqq)a[-1]}
print -r -- step:713:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'café']}:${(qqq)a[-1]}
print -r -- step:714:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key9]='café'
print -r -- step:715:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_215='café'; psh-outer 716
print -r -- step:716:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 717
print -r -- step:717:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key20]='plain'
print -r -- step:718:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_11
print -r -- step:719:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key27]='x:y'
print -r -- step:720:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a'\''b'; print -r -- scalar:${(qqq)s[1,2]}:${(qqq)s//a/A}
print -r -- step:721:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 722
print -r -- step:722:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_227='a'\''b'; psh-outer 723
print -r -- step:723:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:724:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key13]=''
print -r -- step:725:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a'\''b')
print -r -- step:726:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 727
print -r -- step:727:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 728
print -r -- step:728:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a b']}:${(qqq)a[-1]}
print -r -- step:729:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key2]"
print -r -- step:730:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_49='one
two'; psh-outer 731
print -r -- step:731:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[9]='a b'
print -r -- step:732:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=()
print -r -- step:733:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_25
print -r -- step:734:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_132
print -r -- step:735:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[20]='plain'
print -r -- step:736:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key2]"
print -r -- step:737:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key7]='plain'
print -r -- step:738:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:739:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s=''; print -r -- scalar:${(qqq)s[1,4]}:${(qqq)s//a/A}
print -r -- step:740:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 741
print -r -- step:741:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[32]='a'\''b'
print -r -- step:742:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(98*3+743)%97 ))
print -r -- step:743:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:744:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key20]"
print -r -- step:745:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[29]=()
print -r -- step:746:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'café']}:${(qqq)a[-1]}
print -r -- step:747:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[15]='*[x]?'
print -r -- step:748:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[29]='plain'
print -r -- step:749:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key10]='plain'
print -r -- step:750:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='*[x]?'; print -r -- scalar:${(qqq)s[1,6]}:${(qqq)s//a/A}
print -r -- step:751:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:752:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(23*3+753)%97 ))
print -r -- step:753:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[11]=()
print -r -- step:754:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('plain' 'a'\''b' 'x:y' 'x:y' 'café' 'café')
print -r -- step:755:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(15*3+756)%97 ))
print -r -- step:756:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a'\''b')
print -r -- step:757:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='plain'; print -r -- scalar:${(qqq)s[1,3]}:${(qqq)s//a/A}
print -r -- step:758:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:759:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key25]='*[x]?'
print -r -- step:760:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[11]=()
print -r -- step:761:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(11*3+762)%97 ))
print -r -- step:762:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 763
print -r -- step:763:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[9]=''
print -r -- step:764:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('x:y')
print -r -- step:765:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('café')
print -r -- step:766:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key7]"
print -r -- step:767:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_161
print -r -- step:768:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_138='x:y'; psh-outer 769
print -r -- step:769:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key11]='a b'
print -r -- step:770:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 771
print -r -- step:771:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 772
print -r -- step:772:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key26]"
print -r -- step:773:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 774
print -r -- step:774:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:775:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_9='café'; psh-outer 776
print -r -- step:776:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key3]"
print -r -- step:777:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(6*3+778)%97 ))
print -r -- step:778:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='界'; print -r -- scalar:${(qqq)s[1,6]}:${(qqq)s//a/A}
print -r -- step:779:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a'\''b']}:${(qqq)a[-1]}
print -r -- step:780:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 781
print -r -- step:781:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:782:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:783:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:784:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 785
print -r -- step:785:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 786
print -r -- step:786:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(42*3+787)%97 ))
print -r -- step:787:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[18]=()
print -r -- step:788:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='x:y'; print -r -- scalar:${(qqq)s[1,3]}:${(qqq)s//a/A}
print -r -- step:789:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[31]='café'
print -r -- step:790:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_83='界'; psh-outer 791
print -r -- step:791:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 792
print -r -- step:792:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('界')
print -r -- step:793:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:794:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_107
print -r -- step:795:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('*[x]?')
print -r -- step:796:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key8]"
print -r -- step:797:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:798:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[19]='x:y'
print -r -- step:799:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a'\''b']}:${(qqq)a[-1]}
print -r -- step:800:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key17]='café'
print -r -- step:801:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'*[x]?']}:${(qqq)a[-1]}
print -r -- step:802:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='*[x]?'; print -r -- scalar:${(qqq)s[1,1]}:${(qqq)s//a/A}
print -r -- step:803:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s=''; print -r -- scalar:${(qqq)s[1,4]}:${(qqq)s//a/A}
print -r -- step:804:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key7]"
print -r -- step:805:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key31]='plain'
print -r -- step:806:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key3]"
print -r -- step:807:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_141='*[x]?'; psh-outer 808
print -r -- step:808:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[1]='x:y'
print -r -- step:809:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'one
two']}:${(qqq)a[-1]}
print -r -- step:810:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 811
print -r -- step:811:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('plain' 'café' 'a b' '*[x]?' 'a b' 'café' 'x:y')
print -r -- step:812:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[1]='x:y'
print -r -- step:813:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[2]='a'\''b'
print -r -- step:814:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:815:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='one
two'; print -r -- scalar:${(qqq)s[1,6]}:${(qqq)s//a/A}
print -r -- step:816:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('café')
print -r -- step:817:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[16]=()
print -r -- step:818:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:819:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key16]"
print -r -- step:820:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key2]='a b'
print -r -- step:821:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:822:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'x:y']}:${(qqq)a[-1]}
print -r -- step:823:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key22]='*[x]?'
print -r -- step:824:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[12]=()
print -r -- step:825:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[23]='plain'
print -r -- step:826:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a b'; print -r -- scalar:${(qqq)s[1,1]}:${(qqq)s//a/A}
print -r -- step:827:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='plain'; print -r -- scalar:${(qqq)s[1,2]}:${(qqq)s//a/A}
print -r -- step:828:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[16]=()
print -r -- step:829:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:830:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 831
print -r -- step:831:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 832
print -r -- step:832:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_96
print -r -- step:833:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_148='café'; psh-outer 834
print -r -- step:834:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_0='plain'; psh-outer 835
print -r -- step:835:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_155
print -r -- step:836:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('')
print -r -- step:837:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('*[x]?')
print -r -- step:838:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=()
print -r -- step:839:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[1]=()
print -r -- step:840:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('x:y' 'one
two')
print -r -- step:841:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:842:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='plain'; print -r -- scalar:${(qqq)s[1,3]}:${(qqq)s//a/A}
print -r -- step:843:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('a'\''b' 'a b' 'café' 'a'\''b' '' '*[x]?')
print -r -- step:844:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_125
print -r -- step:845:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_24=''; psh-outer 846
print -r -- step:846:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'界']}:${(qqq)a[-1]}
print -r -- step:847:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('plain' 'a b' '*[x]?')
print -r -- step:848:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[20]='*[x]?'
print -r -- step:849:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a'\''b'; print -r -- scalar:${(qqq)s[1,2]}:${(qqq)s//a/A}
print -r -- step:850:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:851:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[27]='界'
print -r -- step:852:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('界' '界' 'one
two' 'a'\''b' 'x:y' '界' 'plain' 'one
two')
print -r -- step:853:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key10]='plain'
print -r -- step:854:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[21]=''
print -r -- step:855:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key26]='one
two'
print -r -- step:856:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('界' 'x:y' 'a b' 'a'\''b' '' '界' 'a b' '界')
print -r -- step:857:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 858
print -r -- step:858:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key3]='*[x]?'
print -r -- step:859:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[23]=()
print -r -- step:860:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[15]=()
print -r -- step:861:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_128='界'; psh-outer 862
print -r -- step:862:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('' 'one
two' 'a'\''b' 'plain' 'a b' '界' 'one
two' 'a b')
print -r -- step:863:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(70*3+864)%97 ))
print -r -- step:864:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:865:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[19]='plain'
print -r -- step:866:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_123='x:y'; psh-outer 867
print -r -- step:867:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key12]"
print -r -- step:868:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a'\''b')
print -r -- step:869:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_66='café'; psh-outer 870
print -r -- step:870:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:871:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 872
print -r -- step:872:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='café'; print -r -- scalar:${(qqq)s[1,2]}:${(qqq)s//a/A}
print -r -- step:873:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:874:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key14]='plain'
print -r -- step:875:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_15='plain'; psh-outer 876
print -r -- step:876:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_188=''; psh-outer 877
print -r -- step:877:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(83*3+878)%97 ))
print -r -- step:878:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key9]='plain'
print -r -- step:879:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='*[x]?'; print -r -- scalar:${(qqq)s[1,3]}:${(qqq)s//a/A}
print -r -- step:880:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:881:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('')
print -r -- step:882:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('one
two')
print -r -- step:883:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_252='one
two'; psh-outer 884
print -r -- step:884:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[22]=()
print -r -- step:885:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_174=''; psh-outer 886
print -r -- step:886:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'界']}:${(qqq)a[-1]}
print -r -- step:887:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('x:y')
print -r -- step:888:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 889
print -r -- step:889:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(31*3+890)%97 ))
print -r -- step:890:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'*[x]?']}:${(qqq)a[-1]}
print -r -- step:891:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a'\''b'; print -r -- scalar:${(qqq)s[1,5]}:${(qqq)s//a/A}
print -r -- step:892:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key7]"
print -r -- step:893:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('')
print -r -- step:894:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[4]=()
print -r -- step:895:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:896:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(81*3+897)%97 ))
print -r -- step:897:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 898
print -r -- step:898:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[25]='a b'
print -r -- step:899:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('' 'plain')
print -r -- step:900:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[4]=()
print -r -- step:901:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_191
print -r -- step:902:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_25
print -r -- step:903:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[9]=()
print -r -- step:904:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('plain' 'a'\''b' 'x:y' 'x:y' 'a'\''b' '' 'one
two' '*[x]?')
print -r -- step:905:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_153
print -r -- step:906:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_25
print -r -- step:907:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key25]='x:y'
print -r -- step:908:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key7]"
print -r -- step:909:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 910
print -r -- step:910:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'plain']}:${(qqq)a[-1]}
print -r -- step:911:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'plain']}:${(qqq)a[-1]}
print -r -- step:912:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_53
print -r -- step:913:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=()
print -r -- step:914:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_10='a b'; psh-outer 915
print -r -- step:915:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_154='x:y'; psh-outer 916
print -r -- step:916:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_228
print -r -- step:917:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('plain' '*[x]?' 'plain' 'café')
print -r -- step:918:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key16]"
print -r -- step:919:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_232='a b'; psh-outer 920
print -r -- step:920:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('x:y')
print -r -- step:921:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:922:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key21]"
print -r -- step:923:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[25]=''
print -r -- step:924:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_155='a b'; psh-outer 925
print -r -- step:925:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('*[x]?')
print -r -- step:926:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_88
print -r -- step:927:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 928
print -r -- step:928:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[29]=()
print -r -- step:929:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(6*3+930)%97 ))
print -r -- step:930:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(76*3+931)%97 ))
print -r -- step:931:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(1*3+932)%97 ))
print -r -- step:932:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'x:y']}:${(qqq)a[-1]}
print -r -- step:933:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'café']}:${(qqq)a[-1]}
print -r -- step:934:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a'\''b')
print -r -- step:935:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key0]='café'
print -r -- step:936:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key4]"
print -r -- step:937:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key16]"
print -r -- step:938:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 939
print -r -- step:939:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key24]"
print -r -- step:940:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_124=''; psh-outer 941
print -r -- step:941:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:942:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='界'; print -r -- scalar:${(qqq)s[1,3]}:${(qqq)s//a/A}
print -r -- step:943:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('a b' '*[x]?' 'a b' '界' 'a'\''b')
print -r -- step:944:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[4]=''
print -r -- step:945:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('café' 'café' 'plain' 'café' 'café' 'one
two' 'café' 'a'\''b')
print -r -- step:946:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key23]='a'\''b'
print -r -- step:947:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_5
print -r -- step:948:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('*[x]?')
print -r -- step:949:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='*[x]?'; print -r -- scalar:${(qqq)s[1,4]}:${(qqq)s//a/A}
print -r -- step:950:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[17]=()
print -r -- step:951:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_57='one
two'; psh-outer 952
print -r -- step:952:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key10]"
print -r -- step:953:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 954
print -r -- step:954:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key26]"
print -r -- step:955:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key9]='plain'
print -r -- step:956:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:957:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key23]='plain'
print -r -- step:958:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[10]=()
print -r -- step:959:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_218
print -r -- step:960:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[1]='界'
print -r -- step:961:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_48
print -r -- step:962:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_102
print -r -- step:963:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a'\''b'; print -r -- scalar:${(qqq)s[1,8]}:${(qqq)s//a/A}
print -r -- step:964:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='x:y'; print -r -- scalar:${(qqq)s[1,1]}:${(qqq)s//a/A}
print -r -- step:965:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key10]"
print -r -- step:966:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_199
print -r -- step:967:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('*[x]?' 'x:y' '*[x]?' 'one
two' '界' 'a b' '')
print -r -- step:968:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[9]=()
print -r -- step:969:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_220
print -r -- step:970:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:971:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a'\''b']}:${(qqq)a[-1]}
print -r -- step:972:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='one
two'; print -r -- scalar:${(qqq)s[1,8]}:${(qqq)s//a/A}
print -r -- step:973:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('a'\''b' '*[x]?' 'a b' 'café' 'a b' 'x:y')
print -r -- step:974:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:975:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 976
print -r -- step:976:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[3]=()
print -r -- step:977:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('one
two')
print -r -- step:978:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[18]='a b'
print -r -- step:979:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[20]='界'
print -r -- step:980:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('café')
print -r -- step:981:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[19]='a b'
print -r -- step:982:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('')
print -r -- step:983:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a'\''b']}:${(qqq)a[-1]}
print -r -- step:984:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_28='one
two'; psh-outer 985
print -r -- step:985:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_247
print -r -- step:986:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='*[x]?'; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:987:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'plain']}:${(qqq)a[-1]}
print -r -- step:988:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[3]='café'
print -r -- step:989:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key1]"
print -r -- step:990:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('*[x]?')
print -r -- step:991:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key13]"
print -r -- step:992:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('')
print -r -- step:993:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_59
print -r -- step:994:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a'\''b')
print -r -- step:995:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[9]=()
print -r -- step:996:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='café'; print -r -- scalar:${(qqq)s[1,4]}:${(qqq)s//a/A}
print -r -- step:997:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='界'; print -r -- scalar:${(qqq)s[1,4]}:${(qqq)s//a/A}
print -r -- step:998:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(42*3+999)%97 ))
print -r -- step:999:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- STATEFUL_COMPLETE
