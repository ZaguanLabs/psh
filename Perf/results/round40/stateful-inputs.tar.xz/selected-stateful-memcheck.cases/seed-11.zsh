emulate -R zsh
setopt extendedglob
typeset -a a=(one two three)
typeset -A h=(first original)
typeset s='original'
integer total=0
psh-inner() { local -a a=(inner nested); local s=inner; print -r -- scope:$1:${(qqq)a}:${(qqq)s}; a[2]=changed; }
psh-outer() { emulate -L zsh; local -a a=(local outer); local s=outer; local -A h=(scope local); psh-inner $1; unset a; local -i a=17; (( a+=3 )); print -r -- restored:$a:$s:$h[scope]; }
psh-recover() { local -i n=7; ( eval '(( 1 / 0 ))' ); local status_code=$?; (( n+=5 )); print -r -- recovery:$status_code:$n; }
typeset -g psh_pad_97='x:y'; psh-outer 0
print -r -- step:0:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('café')
print -r -- step:1:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('x:y')
print -r -- step:2:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 3
print -r -- step:3:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=()
print -r -- step:4:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:5:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_100
print -r -- step:6:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 7
print -r -- step:7:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(35*3+8)%97 ))
print -r -- step:8:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key16]"
print -r -- step:9:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('界')
print -r -- step:10:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key6]='plain'
print -r -- step:11:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(0*3+12)%97 ))
print -r -- step:12:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 13
print -r -- step:13:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a'\''b')
print -r -- step:14:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('界')
print -r -- step:15:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a b'; print -r -- scalar:${(qqq)s[1,2]}:${(qqq)s//a/A}
print -r -- step:16:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=()
print -r -- step:17:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(71*3+18)%97 ))
print -r -- step:18:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'界']}:${(qqq)a[-1]}
print -r -- step:19:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('café')
print -r -- step:20:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('a b' '' '界' 'café')
print -r -- step:21:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[7]='a'\''b'
print -r -- step:22:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('a b' 'a'\''b' 'plain' 'plain' 'plain')
print -r -- step:23:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_188
print -r -- step:24:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_247
print -r -- step:25:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(19*3+26)%97 ))
print -r -- step:26:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a b']}:${(qqq)a[-1]}
print -r -- step:27:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(49*3+28)%97 ))
print -r -- step:28:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('plain')
print -r -- step:29:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'']}:${(qqq)a[-1]}
print -r -- step:30:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_251
print -r -- step:31:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[12]='a b'
print -r -- step:32:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key4]='界'
print -r -- step:33:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('界')
print -r -- step:34:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[27]=()
print -r -- step:35:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key11]=''
print -r -- step:36:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key5]"
print -r -- step:37:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(93*3+38)%97 ))
print -r -- step:38:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('*[x]?' 'a b' '' '' 'plain' 'x:y' 'plain')
print -r -- step:39:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('a b')
print -r -- step:40:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'plain']}:${(qqq)a[-1]}
print -r -- step:41:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key21]"
print -r -- step:42:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='plain'; print -r -- scalar:${(qqq)s[1,1]}:${(qqq)s//a/A}
print -r -- step:43:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='x:y'; print -r -- scalar:${(qqq)s[1,1]}:${(qqq)s//a/A}
print -r -- step:44:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(14*3+45)%97 ))
print -r -- step:45:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a b'; print -r -- scalar:${(qqq)s[1,8]}:${(qqq)s//a/A}
print -r -- step:46:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_15='x:y'; psh-outer 47
print -r -- step:47:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('plain' 'x:y' 'x:y')
print -r -- step:48:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key23]='a b'
print -r -- step:49:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:50:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[29]=()
print -r -- step:51:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[26]=()
print -r -- step:52:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a'\''b'; print -r -- scalar:${(qqq)s[1,4]}:${(qqq)s//a/A}
print -r -- step:53:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[14]='*[x]?'
print -r -- step:54:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'x:y']}:${(qqq)a[-1]}
print -r -- step:55:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('plain')
print -r -- step:56:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[31]=()
print -r -- step:57:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(40*3+58)%97 ))
print -r -- step:58:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('' 'a b' '*[x]?' 'a b')
print -r -- step:59:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 60
print -r -- step:60:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[2]=()
print -r -- step:61:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 62
print -r -- step:62:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(25*3+63)%97 ))
print -r -- step:63:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[31]='界'
print -r -- step:64:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[31]=''
print -r -- step:65:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_81='界'; psh-outer 66
print -r -- step:66:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a'\''b'; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:67:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[29]=()
print -r -- step:68:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 69
print -r -- step:69:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'*[x]?']}:${(qqq)a[-1]}
print -r -- step:70:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='plain'; print -r -- scalar:${(qqq)s[1,2]}:${(qqq)s//a/A}
print -r -- step:71:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a b']}:${(qqq)a[-1]}
print -r -- step:72:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('*[x]?' 'one
two' 'a'\''b' 'a b' 'x:y' '' '界')
print -r -- step:73:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[28]='plain'
print -r -- step:74:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 75
print -r -- step:75:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_44
print -r -- step:76:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'界']}:${(qqq)a[-1]}
print -r -- step:77:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key16]='one
two'
print -r -- step:78:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[14]='a'\''b'
print -r -- step:79:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[18]=()
print -r -- step:80:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_193
print -r -- step:81:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_62=''; psh-outer 82
print -r -- step:82:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('x:y')
print -r -- step:83:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:84:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 85
print -r -- step:85:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='x:y'; print -r -- scalar:${(qqq)s[1,8]}:${(qqq)s//a/A}
print -r -- step:86:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[21]=()
print -r -- step:87:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[2]='a'\''b'
print -r -- step:88:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[3]=''
print -r -- step:89:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key18]"
print -r -- step:90:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('*[x]?')
print -r -- step:91:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'x:y']}:${(qqq)a[-1]}
print -r -- step:92:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='界'; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:93:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(68*3+94)%97 ))
print -r -- step:94:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[14]=()
print -r -- step:95:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_161
print -r -- step:96:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('界')
print -r -- step:97:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'café']}:${(qqq)a[-1]}
print -r -- step:98:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('plain')
print -r -- step:99:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[27]=()
print -r -- step:100:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[2]=()
print -r -- step:101:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'*[x]?']}:${(qqq)a[-1]}
print -r -- step:102:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:103:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=()
print -r -- step:104:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[31]=()
print -r -- step:105:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[8]='café'
print -r -- step:106:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_31
print -r -- step:107:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:108:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 109
print -r -- step:109:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[23]=()
print -r -- step:110:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[1]=()
print -r -- step:111:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key29]"
print -r -- step:112:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_84
print -r -- step:113:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('plain')
print -r -- step:114:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:115:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a b']}:${(qqq)a[-1]}
print -r -- step:116:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key8]"
print -r -- step:117:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:118:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'café']}:${(qqq)a[-1]}
print -r -- step:119:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key21]='café'
print -r -- step:120:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key0]"
print -r -- step:121:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(38*3+122)%97 ))
print -r -- step:122:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_93
print -r -- step:123:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_254='one
two'; psh-outer 124
print -r -- step:124:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_11
print -r -- step:125:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key15]='plain'
print -r -- step:126:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:127:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('界')
print -r -- step:128:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key17]"
print -r -- step:129:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(56*3+130)%97 ))
print -r -- step:130:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[3]='plain'
print -r -- step:131:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 132
print -r -- step:132:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 133
print -r -- step:133:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_159
print -r -- step:134:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(34*3+135)%97 ))
print -r -- step:135:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=()
print -r -- step:136:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='界'; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:137:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('plain' '界' 'a'\''b' 'x:y' 'a b')
print -r -- step:138:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:139:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_58
print -r -- step:140:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('')
print -r -- step:141:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_79='界'; psh-outer 142
print -r -- step:142:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[24]='plain'
print -r -- step:143:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(74*3+144)%97 ))
print -r -- step:144:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key8]='a'\''b'
print -r -- step:145:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('café')
print -r -- step:146:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key22]='one
two'
print -r -- step:147:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:148:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_100='界'; psh-outer 149
print -r -- step:149:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- STATEFUL_COMPLETE
