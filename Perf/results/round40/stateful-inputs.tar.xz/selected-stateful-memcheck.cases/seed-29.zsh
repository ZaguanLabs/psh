emulate -R zsh
setopt extendedglob
typeset -a a=(one two three)
typeset -A h=(first original)
typeset s='original'
integer total=0
psh-inner() { local -a a=(inner nested); local s=inner; print -r -- scope:$1:${(qqq)a}:${(qqq)s}; a[2]=changed; }
psh-outer() { emulate -L zsh; local -a a=(local outer); local s=outer; local -A h=(scope local); psh-inner $1; unset a; local -i a=17; (( a+=3 )); print -r -- restored:$a:$s:$h[scope]; }
psh-recover() { local -i n=7; ( eval '(( 1 / 0 ))' ); local status_code=$?; (( n+=5 )); print -r -- recovery:$status_code:$n; }
unset psh_pad_147
print -r -- step:0:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='plain'; print -r -- scalar:${(qqq)s[1,1]}:${(qqq)s//a/A}
print -r -- step:1:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(28*3+2)%97 ))
print -r -- step:2:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key31]"
print -r -- step:3:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 4
print -r -- step:4:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:5:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key27]='a'\''b'
print -r -- step:6:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:7:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:8:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_50
print -r -- step:9:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[9]='*[x]?'
print -r -- step:10:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[5]='*[x]?'
print -r -- step:11:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key29]='a'\''b'
print -r -- step:12:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(35*3+13)%97 ))
print -r -- step:13:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s=''; print -r -- scalar:${(qqq)s[1,3]}:${(qqq)s//a/A}
print -r -- step:14:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=()
print -r -- step:15:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('' '' 'one
two' '' 'café' 'café' 'x:y' '*[x]?')
print -r -- step:16:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'界']}:${(qqq)a[-1]}
print -r -- step:17:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('界' 'plain')
print -r -- step:18:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[3]=()
print -r -- step:19:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key15]"
print -r -- step:20:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:21:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(53*3+22)%97 ))
print -r -- step:22:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key26]=''
print -r -- step:23:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(14*3+24)%97 ))
print -r -- step:24:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a'\''b'; print -r -- scalar:${(qqq)s[1,8]}:${(qqq)s//a/A}
print -r -- step:25:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[21]=''
print -r -- step:26:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_241
print -r -- step:27:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[6]=()
print -r -- step:28:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[3]=()
print -r -- step:29:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(65*3+30)%97 ))
print -r -- step:30:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('' 'one
two' 'x:y' 'a b' '' 'plain' 'a b')
print -r -- step:31:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('界')
print -r -- step:32:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('界')
print -r -- step:33:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('*[x]?' '界')
print -r -- step:34:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(32*3+35)%97 ))
print -r -- step:35:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a b'; print -r -- scalar:${(qqq)s[1,8]}:${(qqq)s//a/A}
print -r -- step:36:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a b']}:${(qqq)a[-1]}
print -r -- step:37:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('café')
print -r -- step:38:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[15]='plain'
print -r -- step:39:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:40:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(13*3+41)%97 ))
print -r -- step:41:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('*[x]?')
print -r -- step:42:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_177
print -r -- step:43:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 44
print -r -- step:44:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:45:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a'\''b'; print -r -- scalar:${(qqq)s[1,8]}:${(qqq)s//a/A}
print -r -- step:46:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[4]=()
print -r -- step:47:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_151='x:y'; psh-outer 48
print -r -- step:48:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_118='one
two'; psh-outer 49
print -r -- step:49:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[14]=()
print -r -- step:50:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:51:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:52:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'café']}:${(qqq)a[-1]}
print -r -- step:53:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('*[x]?')
print -r -- step:54:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('界')
print -r -- step:55:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a b'; print -r -- scalar:${(qqq)s[1,6]}:${(qqq)s//a/A}
print -r -- step:56:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('café')
print -r -- step:57:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('a'\''b' 'café' 'a'\''b' '' 'plain' 'one
two' 'a'\''b' 'a'\''b')
print -r -- step:58:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('界')
print -r -- step:59:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(72*3+60)%97 ))
print -r -- step:60:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('plain')
print -r -- step:61:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 62
print -r -- step:62:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(30*3+63)%97 ))
print -r -- step:63:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key13]='界'
print -r -- step:64:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='界'; print -r -- scalar:${(qqq)s[1,3]}:${(qqq)s//a/A}
print -r -- step:65:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key7]='*[x]?'
print -r -- step:66:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 67
print -r -- step:67:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:68:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_145
print -r -- step:69:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_18=''; psh-outer 70
print -r -- step:70:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a'\''b']}:${(qqq)a[-1]}
print -r -- step:71:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('x:y' '界' '' '' '界')
print -r -- step:72:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[17]=()
print -r -- step:73:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key16]='plain'
print -r -- step:74:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key5]"
print -r -- step:75:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('*[x]?')
print -r -- step:76:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:77:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='界'; print -r -- scalar:${(qqq)s[1,3]}:${(qqq)s//a/A}
print -r -- step:78:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(46*3+79)%97 ))
print -r -- step:79:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key17]='x:y'
print -r -- step:80:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key5]"
print -r -- step:81:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'one
two']}:${(qqq)a[-1]}
print -r -- step:82:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:83:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[11]=()
print -r -- step:84:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:85:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_80='*[x]?'; psh-outer 86
print -r -- step:86:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key26]"
print -r -- step:87:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[20]='a'\''b'
print -r -- step:88:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 89
print -r -- step:89:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 90
print -r -- step:90:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'*[x]?']}:${(qqq)a[-1]}
print -r -- step:91:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_145='plain'; psh-outer 92
print -r -- step:92:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key1]"
print -r -- step:93:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 94
print -r -- step:94:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key29]"
print -r -- step:95:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_168
print -r -- step:96:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key1]"
print -r -- step:97:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a+=('one
two')
print -r -- step:98:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 99
print -r -- step:99:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:100:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[23]=()
print -r -- step:101:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(53*3+102)%97 ))
print -r -- step:102:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key3]"
print -r -- step:103:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(69*3+104)%97 ))
print -r -- step:104:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('界')
print -r -- step:105:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 106
print -r -- step:106:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_151
print -r -- step:107:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'']}:${(qqq)a[-1]}
print -r -- step:108:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:109:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'界']}:${(qqq)a[-1]}
print -r -- step:110:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[2]=()
print -r -- step:111:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_115
print -r -- step:112:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a b'; print -r -- scalar:${(qqq)s[1,6]}:${(qqq)s//a/A}
print -r -- step:113:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=('one
two' 'a'\''b' '*[x]?' '*[x]?' '' '*[x]?')
print -r -- step:114:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(30*3+115)%97 ))
print -r -- step:115:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_102
print -r -- step:116:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key31]"
print -r -- step:117:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
typeset -g psh_pad_177='one
two'; psh-outer 118
print -r -- step:118:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_136
print -r -- step:119:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key6]"
print -r -- step:120:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:121:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[1]='a'\''b'
print -r -- step:122:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_231
print -r -- step:123:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key19]='plain'
print -r -- step:124:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key31]='x:y'
print -r -- step:125:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key5]"
print -r -- step:126:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_85
print -r -- step:127:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(42*3+128)%97 ))
print -r -- step:128:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key18]='café'
print -r -- step:129:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key14]='a b'
print -r -- step:130:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 131
print -r -- step:131:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:132:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a=()
print -r -- step:133:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
h[key0]='界'
print -r -- step:134:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 135
print -r -- step:135:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[8]=()
print -r -- step:136:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_88
print -r -- step:137:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
(( total+=(8*3+138)%97 ))
print -r -- step:138:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='*[x]?'; print -r -- scalar:${(qqq)s[1,8]}:${(qqq)s//a/A}
print -r -- step:139:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset "h[key10]"
print -r -- step:140:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_110
print -r -- step:141:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-outer 142
print -r -- step:142:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
unset psh_pad_159
print -r -- step:143:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
s='a b'; print -r -- scalar:${(qqq)s[1,7]}:${(qqq)s//a/A}
print -r -- step:144:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- search:${a[(i)'a b']}:${(qqq)a[-1]}
print -r -- step:145:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[17]='界'
print -r -- step:146:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[10]='a'\''b'
print -r -- step:147:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
a[28]='a'\''b'
print -r -- step:148:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
psh-recover
print -r -- step:149:$total:${(qqq)s}
print -rl -- array:${#a} "${(@qqq)a}"
for psh_key in ${(ok)h}; do print -r -- map:${(qqq)psh_key}:${(qqq)h[$psh_key]}; done
print -r -- STATEFUL_COMPLETE
