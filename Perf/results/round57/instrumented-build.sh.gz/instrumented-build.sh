# Run from the repository root after the release-profile build.
mkdir -p .work/round57/ubsan-after/zsh
gcc -shared -fPIC -g -O1 -DHAVE_CONFIG_H -DMODULE -I.work/release-candidate/Src/Modules -I.work/release-candidate/Src -ISrc -ISrc/Zle -ISrc/Modules -fsanitize=undefined,float-cast-overflow Src/Modules/system.c .work/release-candidate/Src/Modules/errnames..o -o .work/round57/ubsan-after/zsh/system.so
python3 Perf/check-flock-interval.py --shell .work/release-candidate/Src/zsh --modules .work/round57/ubsan-after --output .work/round57/ubsan-after.json --require-pass
