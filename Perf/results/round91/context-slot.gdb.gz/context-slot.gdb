Breakpoint 1 at 0x429600: file /home/stig/dev/challenge/zsh-perf/zsh-5.9.2/.work/round90/paren/build/Src/lex.c, line 1685.
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/lib64/libthread_db.so.1".

Breakpoint 1, parse_subscript (s=0x7ffff7fa467b "-6,-1]\220\236", sub=256, endchar=93) at /home/stig/dev/challenge/zsh-perf/zsh-5.9.2/.work/round90/paren/build/Src/lex.c:1685
1685	    int l = strlen(s), err, toklen;
0x4de188 <cstack>:	0x0000000000000000
