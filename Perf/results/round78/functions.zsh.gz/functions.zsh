emulate -R zsh
fpath=("$1" $fpath)
autoload -Uk replaced vanished
autoload +X replaced vanished || exit 2
replaced one '' three || exit 3
vanished
print -r -- "missing-status:$?"
ordinary() { unfunction ordinary; print -r -- "ordinary:$0:$funcstack[1]"; }
ordinary || exit 4
TRAPEXIT() { print -r -- direct-exit; }
TRAPEXIT
unfunction TRAPEXIT
