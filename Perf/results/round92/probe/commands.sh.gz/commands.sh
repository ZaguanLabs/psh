set -eu
w=$PWD/.work/round92
tag=$1
case $tag in
    pristine) b=$PWD/.work/rc0-release-baseline; src=$PWD/.work/pristine; shell=$b/Src/zsh;;
    base) b=$PWD/.work/round91/outer/build; src=$b; shell=$PWD/.work/round91/outer/runtime/bin/zsh;;
    *) b=$w/$tag/build; src=$b; shell=$w/$tag/runtime/bin/zsh;;
esac
d=$w/probe/$tag
mkdir -p "$d"
cc -shared -fPIC -O2 -g -Wall -Werror -DMODULE -DHAVE_CONFIG_H -I"$b/Src" -I"$src/Src" Perf/results/round92/pipeline.c -o "$d/pipeline_probe.so"
for mode in direct memcheck; do
    cmd=()
    if [[ $mode == memcheck ]]; then cmd=(valgrind --tool=memcheck --error-exitcode=97 --leak-check=no --log-file="$d/memcheck.log"); fi
    env -i LC_ALL=C.UTF-8 PATH=/usr/bin:/bin "${cmd[@]}" "$shell" -dfc 'module_path=("$1" $module_path); zmodload pipeline_probe && pipeline-probe 0 && (pipeline-probe 0) && eval "pipeline-probe 0" && print passed' probe "$d" > "$d/$mode.out" 2> "$d/$mode.err"
    test "$(cat "$d/$mode.out")" = passed
    test ! -s "$d/$mode.err"
done
fixture=$PWD/Perf/results/round92/resume.zsh
(cd "$d" && env -i PATH=/usr/bin:/bin LC_ALL=C HOME="$d" TERM=dumb timeout 8 script -qefc "\"$shell\" -dfim \"$fixture\"" /dev/null </dev/null > resume.out)
rg -q '^resumed-payload' "$d/resume.out"
rg -q '^done' "$d/resume.out"
cmp "$w/probe/pristine/suspended" "$d/suspended"
