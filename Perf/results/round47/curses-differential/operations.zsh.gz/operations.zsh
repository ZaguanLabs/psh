emulate -R zsh
setopt nounset
module_path=("$1")
typeset cmd=$2 report_fd=$4 rc key
typeset -a cell position saved
typeset -i y x operation
if [[ $cmd == zcurses ]]; then zmodload zsh/curses; else zmodload zdraw; fi
(( $? == 0 )) || exit 1
"$cmd" init || exit 1
"$cmd" addwin sample 6 16 1 1 || exit 1
print -r -u "$report_fd" -- 0
record() {
               print -rn -u "$report_fd" -- "$operation"$'\0'"$rc"$'\0'
               "$cmd" position sample position || exit 2
               "$cmd" querychar sample cell || exit 2
               for key in "${position[@]}" "${cell[@]}"; do
                 print -rn -u "$report_fd" -- "$key"$'\0'
               done
               print -r -u "$report_fd" -- ''
             }
             snapshot() {
               "$cmd" position sample saved || exit 2
               for (( y=0; y<6; y++ )); do
                 for (( x=0; x<16; x++ )); do
                   "$cmd" move sample "$y" "$x" || exit 2
                   "$cmd" querychar sample cell || exit 2
                   for key in "${cell[@]}"; do print -rn -u "$report_fd" -- "$key"$'\0'; done
                 done
               done
               "$cmd" move sample "$saved[1]" "$saved[2]" || exit 2
             }
operation=0
"$cmd" attr sample underline 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=1
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=2
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=3
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=4
"$cmd" attr sample bold 2>/dev/null
rc=$?
record
operation=5
"$cmd" attr sample bold 2>/dev/null
rc=$?
record
operation=6
"$cmd" string sample 'é!' 2>/dev/null
rc=$?
record
operation=7
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=8
"$cmd" string sample Z9 2>/dev/null
rc=$?
record
operation=9
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=10
"$cmd" string sample '' 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=11
"$cmd" attr sample default/default 2>/dev/null
rc=$?
record
operation=12
"$cmd" attr sample default/default 2>/dev/null
rc=$?
record
operation=13
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=14
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=15
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=16
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=17
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
operation=18
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=19
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=20
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=21
"$cmd" attr sample -bold 2>/dev/null
rc=$?
record
operation=22
"$cmd" string sample hello 2>/dev/null
rc=$?
record
operation=23
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=24
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=25
"$cmd" move sample -1 9 2>/dev/null
rc=$?
record
operation=26
"$cmd" attr sample green/black 2>/dev/null
rc=$?
record
operation=27
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=28
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=29
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=30
"$cmd" attr sample -bold 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=31
"$cmd" bg sample blue/black 2>/dev/null
rc=$?
record
operation=32
"$cmd" move sample 3 6 2>/dev/null
rc=$?
record
operation=33
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=34
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=35
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=36
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=37
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=38
"$cmd" move sample 2 11 2>/dev/null
rc=$?
record
operation=39
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=40
"$cmd" move sample 3 5 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=41
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=42
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=43
"$cmd" attr sample -bold 2>/dev/null
rc=$?
record
operation=44
"$cmd" attr sample bold 2>/dev/null
rc=$?
record
operation=45
"$cmd" move sample -1 -1 2>/dev/null
rc=$?
record
operation=46
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=47
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=48
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=49
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=50
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=51
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
operation=52
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=53
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=54
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=55
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=56
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=57
"$cmd" bg sample blue/black 2>/dev/null
rc=$?
record
operation=58
"$cmd" attr sample -bold 2>/dev/null
rc=$?
record
operation=59
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=60
"$cmd" border sample 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=61
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=62
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=63
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=64
"$cmd" string sample hello 2>/dev/null
rc=$?
record
operation=65
"$cmd" string sample 'é!' 2>/dev/null
rc=$?
record
operation=66
"$cmd" move sample 3 13 2>/dev/null
rc=$?
record
operation=67
"$cmd" scroll sample -1 2>/dev/null
rc=$?
record
operation=68
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=69
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=70
"$cmd" move sample 4 0 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=71
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=72
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=73
"$cmd" move sample 5 0 2>/dev/null
rc=$?
record
operation=74
"$cmd" attr sample underline 2>/dev/null
rc=$?
record
operation=75
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=76
"$cmd" attr sample reverse 2>/dev/null
rc=$?
record
operation=77
"$cmd" string sample 'é!' 2>/dev/null
rc=$?
record
operation=78
"$cmd" scroll sample -1 2>/dev/null
rc=$?
record
operation=79
"$cmd" move sample 2 14 2>/dev/null
rc=$?
record
operation=80
"$cmd" move sample -1 12 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=81
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=82
"$cmd" string sample 'é!' 2>/dev/null
rc=$?
record
operation=83
"$cmd" attr sample -underline 2>/dev/null
rc=$?
record
operation=84
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=85
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=86
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=87
"$cmd" move sample 1 6 2>/dev/null
rc=$?
record
operation=88
"$cmd" string sample Z9 2>/dev/null
rc=$?
record
operation=89
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=90
"$cmd" attr sample underline 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=91
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=92
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
operation=93
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=94
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=95
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
operation=96
"$cmd" move sample 3 13 2>/dev/null
rc=$?
record
operation=97
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=98
"$cmd" move sample -1 12 2>/dev/null
rc=$?
record
operation=99
"$cmd" attr sample default/default 2>/dev/null
rc=$?
record
operation=100
"$cmd" move sample 2 10 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=101
"$cmd" bg sample blue/black 2>/dev/null
rc=$?
record
operation=102
"$cmd" move sample 4 7 2>/dev/null
rc=$?
record
operation=103
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=104
"$cmd" attr sample -reverse 2>/dev/null
rc=$?
record
operation=105
"$cmd" move sample 3 8 2>/dev/null
rc=$?
record
operation=106
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=107
"$cmd" bg sample blue/black 2>/dev/null
rc=$?
record
operation=108
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=109
"$cmd" scroll sample -1 2>/dev/null
rc=$?
record
operation=110
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=111
"$cmd" string sample Z9 2>/dev/null
rc=$?
record
operation=112
"$cmd" attr sample -reverse 2>/dev/null
rc=$?
record
operation=113
"$cmd" attr sample default/default 2>/dev/null
rc=$?
record
operation=114
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=115
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=116
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=117
"$cmd" attr sample default/default 2>/dev/null
rc=$?
record
operation=118
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=119
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=120
"$cmd" attr sample underline 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=121
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=122
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=123
"$cmd" attr sample red/black 2>/dev/null
rc=$?
record
operation=124
"$cmd" attr sample -underline 2>/dev/null
rc=$?
record
operation=125
"$cmd" move sample 1 2 2>/dev/null
rc=$?
record
operation=126
"$cmd" move sample 5 6 2>/dev/null
rc=$?
record
operation=127
"$cmd" move sample 5 9 2>/dev/null
rc=$?
record
operation=128
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=129
"$cmd" move sample 0 9 2>/dev/null
rc=$?
record
operation=130
"$cmd" string sample Z9 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=131
"$cmd" attr sample default/default 2>/dev/null
rc=$?
record
operation=132
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=133
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=134
"$cmd" attr sample reverse 2>/dev/null
rc=$?
record
operation=135
"$cmd" string sample hello 2>/dev/null
rc=$?
record
operation=136
"$cmd" move sample 3 8 2>/dev/null
rc=$?
record
operation=137
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=138
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=139
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
operation=140
"$cmd" border sample 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=141
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=142
"$cmd" attr sample -bold 2>/dev/null
rc=$?
record
operation=143
"$cmd" attr sample red/black 2>/dev/null
rc=$?
record
operation=144
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=145
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=146
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=147
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=148
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=149
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=150
"$cmd" string sample Z9 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=151
"$cmd" move sample 6 14 2>/dev/null
rc=$?
record
operation=152
"$cmd" bg sample blue/black 2>/dev/null
rc=$?
record
operation=153
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=154
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=155
"$cmd" attr sample green/black 2>/dev/null
rc=$?
record
operation=156
"$cmd" attr sample underline 2>/dev/null
rc=$?
record
operation=157
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=158
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=159
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=160
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=161
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=162
"$cmd" attr sample green/black 2>/dev/null
rc=$?
record
operation=163
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=164
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=165
"$cmd" move sample 2 3 2>/dev/null
rc=$?
record
operation=166
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=167
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=168
"$cmd" attr sample green/black 2>/dev/null
rc=$?
record
operation=169
"$cmd" bg sample blue/black 2>/dev/null
rc=$?
record
operation=170
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=171
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=172
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=173
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=174
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=175
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
operation=176
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=177
"$cmd" string sample 'é!' 2>/dev/null
rc=$?
record
operation=178
"$cmd" scroll sample -1 2>/dev/null
rc=$?
record
operation=179
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=180
"$cmd" char sample X 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=181
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=182
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
operation=183
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=184
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
operation=185
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=186
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=187
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=188
"$cmd" move sample 3 1 2>/dev/null
rc=$?
record
operation=189
"$cmd" string sample Z9 2>/dev/null
rc=$?
record
operation=190
"$cmd" attr sample green/black 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=191
"$cmd" scroll sample -1 2>/dev/null
rc=$?
record
operation=192
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=193
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
operation=194
"$cmd" attr sample reverse 2>/dev/null
rc=$?
record
operation=195
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=196
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
operation=197
"$cmd" bg sample blue/black 2>/dev/null
rc=$?
record
operation=198
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=199
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=200
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=201
"$cmd" string sample Z9 2>/dev/null
rc=$?
record
operation=202
"$cmd" move sample 1 12 2>/dev/null
rc=$?
record
operation=203
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
operation=204
"$cmd" move sample 3 8 2>/dev/null
rc=$?
record
operation=205
"$cmd" string sample Z9 2>/dev/null
rc=$?
record
operation=206
"$cmd" string sample hello 2>/dev/null
rc=$?
record
operation=207
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=208
"$cmd" string sample hello 2>/dev/null
rc=$?
record
operation=209
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=210
"$cmd" attr sample reverse 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=211
"$cmd" move sample 3 5 2>/dev/null
rc=$?
record
operation=212
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=213
"$cmd" move sample 6 0 2>/dev/null
rc=$?
record
operation=214
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=215
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=216
"$cmd" scroll sample -1 2>/dev/null
rc=$?
record
operation=217
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=218
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=219
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=220
"$cmd" attr sample default/default 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=221
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
operation=222
"$cmd" move sample 0 10 2>/dev/null
rc=$?
record
operation=223
"$cmd" attr sample bold 2>/dev/null
rc=$?
record
operation=224
"$cmd" string sample Z9 2>/dev/null
rc=$?
record
operation=225
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=226
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=227
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=228
"$cmd" move sample 3 8 2>/dev/null
rc=$?
record
operation=229
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=230
"$cmd" move sample 6 12 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=231
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=232
"$cmd" move sample -1 -1 2>/dev/null
rc=$?
record
operation=233
"$cmd" string sample hello 2>/dev/null
rc=$?
record
operation=234
"$cmd" attr sample reverse 2>/dev/null
rc=$?
record
operation=235
"$cmd" attr sample underline 2>/dev/null
rc=$?
record
operation=236
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
operation=237
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=238
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=239
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=240
"$cmd" border sample 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=241
"$cmd" attr sample red/black 2>/dev/null
rc=$?
record
operation=242
"$cmd" move sample 2 11 2>/dev/null
rc=$?
record
operation=243
"$cmd" move sample 4 6 2>/dev/null
rc=$?
record
operation=244
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=245
"$cmd" move sample 6 8 2>/dev/null
rc=$?
record
operation=246
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=247
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=248
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=249
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=250
"$cmd" attr sample reverse 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=251
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=252
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=253
"$cmd" string sample Z9 2>/dev/null
rc=$?
record
operation=254
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=255
"$cmd" move sample 2 1 2>/dev/null
rc=$?
record
operation=256
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=257
"$cmd" move sample 5 13 2>/dev/null
rc=$?
record
operation=258
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=259
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=260
"$cmd" move sample 6 16 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=261
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=262
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
operation=263
"$cmd" move sample 2 -1 2>/dev/null
rc=$?
record
operation=264
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=265
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=266
"$cmd" attr sample reverse 2>/dev/null
rc=$?
record
operation=267
"$cmd" move sample 6 0 2>/dev/null
rc=$?
record
operation=268
"$cmd" bg sample blue/black 2>/dev/null
rc=$?
record
operation=269
"$cmd" attr sample reverse 2>/dev/null
rc=$?
record
operation=270
"$cmd" string sample hello 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=271
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=272
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=273
"$cmd" string sample '' 2>/dev/null
rc=$?
record
operation=274
"$cmd" string sample '' 2>/dev/null
rc=$?
record
operation=275
"$cmd" string sample '' 2>/dev/null
rc=$?
record
operation=276
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=277
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=278
"$cmd" string sample '' 2>/dev/null
rc=$?
record
operation=279
"$cmd" bg sample blue/black 2>/dev/null
rc=$?
record
operation=280
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=281
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=282
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=283
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=284
"$cmd" attr sample -underline 2>/dev/null
rc=$?
record
operation=285
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
operation=286
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
operation=287
"$cmd" move sample 6 1 2>/dev/null
rc=$?
record
operation=288
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=289
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=290
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=291
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
operation=292
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=293
"$cmd" attr sample reverse 2>/dev/null
rc=$?
record
operation=294
"$cmd" move sample 5 10 2>/dev/null
rc=$?
record
operation=295
"$cmd" bg sample blue/black 2>/dev/null
rc=$?
record
operation=296
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=297
"$cmd" attr sample -underline 2>/dev/null
rc=$?
record
operation=298
"$cmd" move sample 6 16 2>/dev/null
rc=$?
record
operation=299
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
operation=300
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=301
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
operation=302
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
operation=303
"$cmd" attr sample default/default 2>/dev/null
rc=$?
record
operation=304
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=305
"$cmd" move sample 1 3 2>/dev/null
rc=$?
record
operation=306
"$cmd" attr sample -bold 2>/dev/null
rc=$?
record
operation=307
"$cmd" attr sample -underline 2>/dev/null
rc=$?
record
operation=308
"$cmd" move sample 3 6 2>/dev/null
rc=$?
record
operation=309
"$cmd" scroll sample -1 2>/dev/null
rc=$?
record
operation=310
"$cmd" attr sample underline 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=311
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=312
"$cmd" attr sample default/default 2>/dev/null
rc=$?
record
operation=313
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=314
"$cmd" scroll sample -1 2>/dev/null
rc=$?
record
operation=315
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=316
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=317
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=318
"$cmd" move sample 0 5 2>/dev/null
rc=$?
record
operation=319
"$cmd" attr sample -underline 2>/dev/null
rc=$?
record
operation=320
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=321
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=322
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=323
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=324
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=325
"$cmd" bg sample blue/black 2>/dev/null
rc=$?
record
operation=326
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=327
"$cmd" move sample 5 2 2>/dev/null
rc=$?
record
operation=328
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=329
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=330
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=331
"$cmd" attr sample -bold 2>/dev/null
rc=$?
record
operation=332
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=333
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=334
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=335
"$cmd" move sample 5 3 2>/dev/null
rc=$?
record
operation=336
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
operation=337
"$cmd" attr sample bold 2>/dev/null
rc=$?
record
operation=338
"$cmd" string sample 'é!' 2>/dev/null
rc=$?
record
operation=339
"$cmd" string sample Z9 2>/dev/null
rc=$?
record
operation=340
"$cmd" char sample Q 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=341
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=342
"$cmd" attr sample underline 2>/dev/null
rc=$?
record
operation=343
"$cmd" string sample hello 2>/dev/null
rc=$?
record
operation=344
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
operation=345
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=346
"$cmd" move sample 3 -1 2>/dev/null
rc=$?
record
operation=347
"$cmd" attr sample -bold 2>/dev/null
rc=$?
record
operation=348
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=349
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
operation=350
"$cmd" string sample 'é!' 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=351
"$cmd" move sample 4 9 2>/dev/null
rc=$?
record
operation=352
"$cmd" string sample 'é!' 2>/dev/null
rc=$?
record
operation=353
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=354
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=355
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
operation=356
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=357
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
operation=358
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=359
"$cmd" scroll sample -1 2>/dev/null
rc=$?
record
operation=360
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=361
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=362
"$cmd" move sample 1 14 2>/dev/null
rc=$?
record
operation=363
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=364
"$cmd" attr sample underline 2>/dev/null
rc=$?
record
operation=365
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=366
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
operation=367
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=368
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=369
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=370
"$cmd" move sample 6 14 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=371
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=372
"$cmd" string sample '' 2>/dev/null
rc=$?
record
operation=373
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=374
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=375
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=376
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=377
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
operation=378
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=379
"$cmd" move sample 0 3 2>/dev/null
rc=$?
record
operation=380
"$cmd" scroll sample -1 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=381
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
operation=382
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=383
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=384
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=385
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=386
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=387
"$cmd" move sample 0 14 2>/dev/null
rc=$?
record
operation=388
"$cmd" scroll sample -1 2>/dev/null
rc=$?
record
operation=389
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
operation=390
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=391
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=392
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=393
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=394
"$cmd" move sample 5 3 2>/dev/null
rc=$?
record
operation=395
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=396
"$cmd" attr sample -bold 2>/dev/null
rc=$?
record
operation=397
"$cmd" move sample 6 3 2>/dev/null
rc=$?
record
operation=398
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=399
"$cmd" string sample Z9 2>/dev/null
rc=$?
record
operation=400
"$cmd" move sample 6 1 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=401
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=402
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=403
"$cmd" attr sample -bold 2>/dev/null
rc=$?
record
operation=404
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=405
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=406
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=407
"$cmd" attr sample -bold 2>/dev/null
rc=$?
record
operation=408
"$cmd" move sample 3 11 2>/dev/null
rc=$?
record
operation=409
"$cmd" string sample hello 2>/dev/null
rc=$?
record
operation=410
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=411
"$cmd" move sample 5 13 2>/dev/null
rc=$?
record
operation=412
"$cmd" string sample hello 2>/dev/null
rc=$?
record
operation=413
"$cmd" move sample 2 8 2>/dev/null
rc=$?
record
operation=414
"$cmd" scroll sample -1 2>/dev/null
rc=$?
record
operation=415
"$cmd" attr sample reverse 2>/dev/null
rc=$?
record
operation=416
"$cmd" attr sample bold 2>/dev/null
rc=$?
record
operation=417
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=418
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=419
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=420
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=421
"$cmd" attr sample -bold 2>/dev/null
rc=$?
record
operation=422
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=423
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=424
"$cmd" scroll sample -1 2>/dev/null
rc=$?
record
operation=425
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=426
"$cmd" move sample 2 15 2>/dev/null
rc=$?
record
operation=427
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=428
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=429
"$cmd" attr sample green/black 2>/dev/null
rc=$?
record
operation=430
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=431
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=432
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
operation=433
"$cmd" move sample -1 -1 2>/dev/null
rc=$?
record
operation=434
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=435
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=436
"$cmd" move sample 0 5 2>/dev/null
rc=$?
record
operation=437
"$cmd" scroll sample -1 2>/dev/null
rc=$?
record
operation=438
"$cmd" move sample 3 4 2>/dev/null
rc=$?
record
operation=439
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=440
"$cmd" border sample 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=441
"$cmd" move sample 6 16 2>/dev/null
rc=$?
record
operation=442
"$cmd" string sample hello 2>/dev/null
rc=$?
record
operation=443
"$cmd" attr sample -bold 2>/dev/null
rc=$?
record
operation=444
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=445
"$cmd" bg sample blue/black 2>/dev/null
rc=$?
record
operation=446
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
operation=447
"$cmd" string sample 'é!' 2>/dev/null
rc=$?
record
operation=448
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=449
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=450
"$cmd" string sample Z9 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=451
"$cmd" string sample Z9 2>/dev/null
rc=$?
record
operation=452
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=453
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=454
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=455
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
operation=456
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
operation=457
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=458
"$cmd" move sample 4 -1 2>/dev/null
rc=$?
record
operation=459
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
operation=460
"$cmd" border sample 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=461
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=462
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=463
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=464
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
operation=465
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=466
"$cmd" attr sample green/black 2>/dev/null
rc=$?
record
operation=467
"$cmd" scroll sample -1 2>/dev/null
rc=$?
record
operation=468
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
operation=469
"$cmd" attr sample underline 2>/dev/null
rc=$?
record
operation=470
"$cmd" attr sample underline 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=471
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
operation=472
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
operation=473
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=474
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=475
"$cmd" attr sample bold 2>/dev/null
rc=$?
record
operation=476
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=477
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=478
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
operation=479
"$cmd" move sample 0 5 2>/dev/null
rc=$?
record
operation=480
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=481
"$cmd" move sample 2 1 2>/dev/null
rc=$?
record
operation=482
"$cmd" bg sample blue/black 2>/dev/null
rc=$?
record
operation=483
"$cmd" string sample '' 2>/dev/null
rc=$?
record
operation=484
"$cmd" move sample 1 0 2>/dev/null
rc=$?
record
operation=485
"$cmd" move sample 6 13 2>/dev/null
rc=$?
record
operation=486
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
operation=487
"$cmd" attr sample green/black 2>/dev/null
rc=$?
record
operation=488
"$cmd" move sample -1 6 2>/dev/null
rc=$?
record
operation=489
"$cmd" move sample 1 8 2>/dev/null
rc=$?
record
operation=490
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=491
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=492
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=493
"$cmd" move sample 4 12 2>/dev/null
rc=$?
record
operation=494
"$cmd" attr sample reverse 2>/dev/null
rc=$?
record
operation=495
"$cmd" move sample 5 1 2>/dev/null
rc=$?
record
operation=496
"$cmd" string sample 'é!' 2>/dev/null
rc=$?
record
operation=497
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=498
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=499
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=500
"$cmd" attr sample -underline 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=501
"$cmd" move sample 5 14 2>/dev/null
rc=$?
record
operation=502
"$cmd" attr sample underline 2>/dev/null
rc=$?
record
operation=503
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=504
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=505
"$cmd" move sample 4 9 2>/dev/null
rc=$?
record
operation=506
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
operation=507
"$cmd" string sample Z9 2>/dev/null
rc=$?
record
operation=508
"$cmd" attr sample default/default 2>/dev/null
rc=$?
record
operation=509
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=510
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=511
"$cmd" string sample 'é!' 2>/dev/null
rc=$?
record
operation=512
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=513
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=514
"$cmd" string sample 'é!' 2>/dev/null
rc=$?
record
operation=515
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=516
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
operation=517
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=518
"$cmd" attr sample red/black 2>/dev/null
rc=$?
record
operation=519
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=520
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=521
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=522
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=523
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=524
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=525
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=526
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=527
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=528
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=529
"$cmd" move sample -1 7 2>/dev/null
rc=$?
record
operation=530
"$cmd" bg sample blue/black 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=531
"$cmd" move sample 2 11 2>/dev/null
rc=$?
record
operation=532
"$cmd" attr sample bold 2>/dev/null
rc=$?
record
operation=533
"$cmd" string sample 'é!' 2>/dev/null
rc=$?
record
operation=534
"$cmd" string sample Z9 2>/dev/null
rc=$?
record
operation=535
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=536
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=537
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=538
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=539
"$cmd" move sample 3 4 2>/dev/null
rc=$?
record
operation=540
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=541
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=542
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=543
"$cmd" move sample 4 16 2>/dev/null
rc=$?
record
operation=544
"$cmd" string sample hello 2>/dev/null
rc=$?
record
operation=545
"$cmd" char sample ' ' 2>/dev/null
rc=$?
record
operation=546
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=547
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=548
"$cmd" char sample X 2>/dev/null
rc=$?
record
operation=549
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=550
"$cmd" string sample hello 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=551
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=552
"$cmd" move sample 3 4 2>/dev/null
rc=$?
record
operation=553
"$cmd" string sample hello 2>/dev/null
rc=$?
record
operation=554
"$cmd" move sample 0 8 2>/dev/null
rc=$?
record
operation=555
"$cmd" string sample '界x' 2>/dev/null
rc=$?
record
operation=556
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=557
"$cmd" move sample -1 13 2>/dev/null
rc=$?
record
operation=558
"$cmd" string sample 'é!' 2>/dev/null
rc=$?
record
operation=559
"$cmd" bg sample blue/black 2>/dev/null
rc=$?
record
operation=560
"$cmd" bg sample @. 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=561
"$cmd" move sample 6 -1 2>/dev/null
rc=$?
record
operation=562
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=563
"$cmd" string sample 'é!' 2>/dev/null
rc=$?
record
operation=564
"$cmd" move sample -1 9 2>/dev/null
rc=$?
record
operation=565
"$cmd" string sample 'é!' 2>/dev/null
rc=$?
record
operation=566
"$cmd" move sample 2 9 2>/dev/null
rc=$?
record
operation=567
"$cmd" move sample -1 10 2>/dev/null
rc=$?
record
operation=568
"$cmd" move sample 4 7 2>/dev/null
rc=$?
record
operation=569
"$cmd" scroll sample off 2>/dev/null
rc=$?
record
operation=570
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=571
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
operation=572
"$cmd" scroll sample 1 2>/dev/null
rc=$?
record
operation=573
"$cmd" bg sample '@ ' 2>/dev/null
rc=$?
record
operation=574
"$cmd" attr sample red/black 2>/dev/null
rc=$?
record
operation=575
"$cmd" attr sample underline 2>/dev/null
rc=$?
record
operation=576
"$cmd" attr sample default/default 2>/dev/null
rc=$?
record
operation=577
"$cmd" attr sample green/black 2>/dev/null
rc=$?
record
operation=578
"$cmd" char sample '!' 2>/dev/null
rc=$?
record
operation=579
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=580
"$cmd" border sample 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=581
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
operation=582
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=583
"$cmd" attr sample -underline 2>/dev/null
rc=$?
record
operation=584
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=585
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=586
"$cmd" move sample 0 1 2>/dev/null
rc=$?
record
operation=587
"$cmd" scroll sample on 2>/dev/null
rc=$?
record
operation=588
"$cmd" attr sample bold 2>/dev/null
rc=$?
record
operation=589
"$cmd" clear sample eol 2>/dev/null
rc=$?
record
operation=590
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
snapshot
"$cmd" refresh sample || exit 2
operation=591
"$cmd" char sample Q 2>/dev/null
rc=$?
record
operation=592
"$cmd" move sample 6 0 2>/dev/null
rc=$?
record
operation=593
"$cmd" attr sample green/black 2>/dev/null
rc=$?
record
operation=594
"$cmd" attr sample bold 2>/dev/null
rc=$?
record
operation=595
"$cmd" border sample 2>/dev/null
rc=$?
record
operation=596
"$cmd" attr sample red/black 2>/dev/null
rc=$?
record
operation=597
"$cmd" clear sample redraw 2>/dev/null
rc=$?
record
operation=598
"$cmd" scroll sample -1 2>/dev/null
rc=$?
record
operation=599
"$cmd" clear sample bot 2>/dev/null
rc=$?
record
snapshot
"$cmd" delwin sample || exit 2
"$cmd" end || exit 2
