#include "zsh.mdh"

static int
sep_alloc_probe(UNUSED(char *name), UNUSED(char **args),
                UNUSED(Options ops), UNUSED(int func))
{
    static char nularg[] = { Nularg, 0 };
    static char unicode[] = "alpha:é:界:tail";
    static char invalid[] = { 'a', ':', (char)0xff, ':', 'b', 0 };
    static char repeat[65 * 2];
    static const struct {
        char *sep;
        char *text;
    } cases[] = {
        { ":", "" }, { ":", ":a::b:" }, { "::", "a::b::::c" },
        { "", "a" }, { "", "" }, { NULL, "  a b  " },
        { ":", unicode }, { ":", invalid }, { ":", nularg },
        { ":", repeat },
    };
    int i;
    int heap;

    memset(repeat, 0, sizeof(repeat));
    for (i = 0; i < 64; i++)
        strcat(repeat, "a:");

    for (heap = 0; heap <= 1; heap++) {
        for (i = 0; i < (int)(sizeof(cases) / sizeof(*cases)); i++) {
            char **result = sepsplit(cases[i].text, cases[i].sep, 0, heap);
            char **ptr = result;

            if (!result)
                return 1;
            for (; *ptr; ptr++) {
                printf("%d/%d:", heap, i);
                printf("%s", *ptr);
                putchar(0);
            }
            if (!heap) {
                char **owned = result;

                for (; *owned; owned++)
                    zsfree(*owned);
                zsfree((char *)result);
            }
        }
    }
    printf("done\n");
    return 0;
}

static struct builtin probe_builtin[] = {
    BUILTIN("sep-alloc-probe", 0, sep_alloc_probe, 0, 0, 0, NULL, NULL)
};
static struct features probe_features = {
    probe_builtin, 1, NULL, 0, NULL, 0, NULL, 0, 0
};

int setup_(UNUSED(Module m)) { return 0; }
int features_(Module m, char ***out) { *out = featuresarray(m, &probe_features); return 0; }
int enables_(Module m, int **out) { return handlefeatures(m, &probe_features, out); }
int boot_(UNUSED(Module m)) { return 0; }
int cleanup_(Module m) { return setfeatureenables(m, &probe_features, NULL); }
int finish_(UNUSED(Module m)) { return 0; }
