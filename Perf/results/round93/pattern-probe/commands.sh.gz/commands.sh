set -eu
w=$PWD/.work/round93
fixture=$PWD/Perf/results/round93
for tag in pristine base pattern; do
    case $tag in
        pristine) b=$PWD/.work/rc0-release-baseline; src=$PWD/.work/pristine; shell=$b/Src/zsh;;
        base) b=$PWD/.work/round92/shared/build; src=$b; shell=$PWD/.work/round92/shared/runtime/bin/zsh;;
        pattern) b=$w/$tag/build; src=$b; shell=$w/$tag/runtime/bin/zsh;;
    esac
    d=$w/pattern-probe/$tag
    mkdir -p "$d"
    cc -shared -fPIC -O2 -g -Wall -Werror -DMODULE -DHAVE_CONFIG_H -I"$b/Src" -I"$src/Src" "$fixture/pattern-scope.c" -o "$d/pattern_scope_probe.so"
    for mode in normal memcheck; do
        cmd=()
        if [[ $mode == memcheck ]]; then cmd=(valgrind --tool=memcheck --error-exitcode=97 --leak-check=no --log-file="$d/memcheck-%p.log"); fi
        env -i LC_ALL=C.UTF-8 PATH=/usr/bin:/bin "${cmd[@]}" "$shell" -df "$fixture/pattern-scope.zsh" "$d" > "$d/$mode.out" 2> "$d/$mode.err"
        test ! -s "$d/$mode.err"
        test "$(tail -1 "$d/$mode.out")" = passed
        cmp "$w/pattern-probe/pristine/normal.out" "$d/$mode.out"
    done
done
