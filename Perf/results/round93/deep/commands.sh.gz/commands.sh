set -eu
w=$PWD/.work/round93
for tag in a d; do
    for mode in enabled disabled; do
        d=$w/deep/$tag/$mode
        mkdir -p "$d"
        env -i LC_ALL=C PATH=/usr/bin:/bin valgrind --tool=dhat --dhat-out-file="$d/profile.json" "$w/$tag/zsh" -dfc '
            FUNCNEST=400
            if [[ $1 == disabled ]]; then disable -p "@(" || exit 1; fi
            walk() { if (( $1 )); then walk $(( $1 - 1 )); else print reached; fi }
            walk 256 && print returned
        ' probe "$mode" > "$d/output" 2> "$d/log"
        cmp "$w/deep/a/enabled/output" "$d/output"
    done
done
